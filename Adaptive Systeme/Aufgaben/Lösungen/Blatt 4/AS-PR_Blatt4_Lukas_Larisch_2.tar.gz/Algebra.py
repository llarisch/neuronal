import copy
from math import sqrt
import numpy


''' checks if family of vectors is pairwise quasi-orthogonal '''    
def isOrthogonal(EVs, error):
    for i in range(0, len(EVs)):
        for j in range(i+1, len(EVs)):
            scalar_value = 0.0
            for k in range(0, len(EVs[0])):
                scalar_value += EVs[i][k]*EVs[j][k]
            if abs(scalar_value) > error:
                return False
    return True

''' @param:  matrix M
    @return: average vector of M        '''
def MatrixAverage(M):
    A = M[0]
    for i in range(1, len(M)):
        A = numpy.add(A, M[i])
    return (1.0/len(M))*A

''' @param:  matrix M, average vector avg_V
    @return: cencentrate vectors due to average vector '''
def MatrixCentrate(M):
    avg_M = MatrixAverage(M)
    for k in range(0, len(M)):
        M[k] = numpy.subtract(M[k], avg_M)
    return M

def VectorNormalize(X):
    X = numpy.dot(1.0/sqrt(numpy.dot(X, X)), X)
    return X

def orthogonalize(EVs, count):
    tmp_EVs = copy.copy(EVs)
    
    for i in range(0, count):
        tmp_EVs.append([1.0 for x in range(0, len(EVs[0]))])
    
    #orthogonalize
    for j in range(len(EVs), len(EVs)+count):
        sum = numpy.array([0.0 for x in range(0, len(EVs[0]))])
        for i in range(0, j):
            sum = numpy.add(sum, numpy.dot(numpy.dot(tmp_EVs[i], tmp_EVs[j]), tmp_EVs[i]))
        tmp_EVs[j] = numpy.subtract(tmp_EVs[j], sum)
        tmp_EVs[j] = VectorNormalize(tmp_EVs[j]).tolist()
    return tmp_EVs

def AutoCorMatrix(X):
    C_xx = numpy.outer(X[0], X[0])
    for i in range(1, len(X)):
        C_xx = numpy.add(C_xx, numpy.outer(X[i], X[i]))
    return (1.0/len(X)) * C_xx


def Eigenvalue(w_i, C_xx_w):
    return (C_xx_w[0] / w_i[0])