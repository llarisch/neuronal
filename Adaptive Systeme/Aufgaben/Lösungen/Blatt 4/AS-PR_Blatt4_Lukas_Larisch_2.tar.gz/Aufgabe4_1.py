#use python27
from ICA import ICA
from PCA import SangerNetwork
from Algebra import MatrixCentrate, AutoCorMatrix
import numpy.linalg as LA
import matplotlib.pyplot as plt
import numpy
import sys

''' ica_signal.dt '''
ICA_SIGNAL = list()

def plot_unprocessed_data(component=int(), name = str(), color = str()):
    G_x = [x for x in range(0, len(ICA_SIGNAL))]
    G_y = list()
    for y in range(0, len(ICA_SIGNAL)):
        G_y.append(ICA_SIGNAL[y][component])
    plt.plot(G_x, G_y, color+'o')
    plt.axis([0, len(ICA_SIGNAL)+1, min(G_y), max(G_y)])
    plt.xlabel("time")
    plt.ylabel(name)
    plt.show()
    
def plot_processed_data(X, component=int(), name=str(), color=str()):
    #plot processed data
    
    #RANGE = len(X)
    RANGE = 500
    G_x = [x for x in range(0, RANGE)]
    
    G_y = list()
    for y in range(0, RANGE):
        G_y.append(X[y][component])

    plt.plot(G_x, G_y, color+'o')
    plt.axis([0, RANGE+1, min(G_y), max(G_y)])
    plt.xlabel("time")
    plt.ylabel(name)
    plt.show()

''' reads data from ica_signal.dt into ICA_SIGNAL '''
def read_data():
    global ICA_SIGNAL
    fin = open('ica_signal.dt', 'r')
    lines = list()
    for line in fin:
        lines.append(line[1:].split(' '))
    
    fin.close()

    for i in range(0, len(lines)):
        V = list()
        for j in range(0, len(lines[0])):
            V.append(float((lines[i][j].replace('\n', '')).replace('\r', '')))
        ICA_SIGNAL.append(V)
        
    
if __name__ == '__main__':
    #read pattern from ica_signals.dt, storing them in ICA_SIGNAL
    read_data()
    
    X = numpy.array(ICA_SIGNAL)
    X = MatrixCentrate(X)

    #applying PCA to X
    LEARN_RATE = 0.1
    eVals, eVecs, dim = SangerNetwork(X, LEARN_RATE) 

    
    print("PCA finished")
    sys.stdout.flush() 

    #applying ICA to X with result from PCA
    ICA_result_set, V = ICA(X, eVals, eVecs, dim)
    
    print("ICA finished")
    sys.stdout.flush()


    RESULT = numpy.dot(V, ICA_result_set)


    plot_unprocessed_data(0, "f(t)", 'r')
    plot_unprocessed_data(1, "g(t)", 'g')
    plot_unprocessed_data(2, "h(t)", 'b')

    plot_processed_data(RESULT, 0, "?(t)", 'm')
    plot_processed_data(RESULT, 1, "?(t)", 'y')
    plot_processed_data(RESULT, 2, "?(t)", 'k')
