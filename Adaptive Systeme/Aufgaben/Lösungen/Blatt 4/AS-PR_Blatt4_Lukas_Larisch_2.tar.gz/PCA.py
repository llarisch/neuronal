#use python 27

from math import sqrt
from Algebra import *
from numpy import linalg as LA


''' @param:  -C_xx_w = product of w_i and C_xx
             -w_i = computed weights vector
             -delta = maximal error
    @return: - (True, -) if converged, (False, -) if not
             - (True, True) if Eigenvalue 0 is at hand '''
def is_converged(C_xx_w, w_i, delta):
    dominator = sqrt(numpy.dot(C_xx_w, C_xx_w))

    #means Null-Eigenvalue
    if dominator < delta:
        return (True, True)

    left_formula = numpy.dot(1.0/dominator,C_xx_w)

    #right_formula = w_i
    sub = numpy.subtract(left_formula, w_i)
    value = sqrt(numpy.dot(sub, sub))

    if value < delta:
        return (True, False)
    return (False, False)


''' @param:  -X = list of patterns
             -w = approximated Eigenvector
    @return: -reduced list of patterns due to Eigenvector 
    see introduction for formula                            '''
def reduceX(X, w):
    new_X = list()
    is_null = 0
    for i in range(0, len(X)):
        scalar_mult = numpy.dot(X[i],w)*w      
        new_vec_x = numpy.subtract(X[i], scalar_mult)  
        #zero X_i if small enough [10**(-12)]
        """
        for j in range(0, len(new_vec_x)):
            if new_vec_x[j] < 10**(-12):
                new_vec_x[j] = 0.0
                is_null += 1
        """
        new_X.append(new_vec_x)
    return (new_X, is_null/len(X[0]) == len(X)) 


''' @param:  -X = list of patterns
             -w_i (initially [])
             -C_xx = auto-correlation matrix
             -learn-rate
    @return: -tuple (Eigenvector, Eigenvalue) due to learning rule 
    see introduction for algorithm                                '''
BEST_EIGENVALUE = 0.0
BEST_EIGENVECTOR = list()

def Hebb_Iteration(X, w_i, C_xx, learn_rate):
    global BEST_EIGENVALUE
    global BEST_EIGENVECTOR
    
    #initial weight = 1^n
    if w_i == []:
        w_i = numpy.array([1.0 for x in range(len(X[0]))])
    
    C_xx_w = numpy.dot(C_xx, w_i)
    while True:
        #apply w_i_inc := w_i + learn_rate*(C_xx*w)
        w_i = w_i + learn_rate*C_xx_w

        #normalize vector
        w_i = VectorNormalize(w_i)
        
        #[precision = 10**(-12)]
        C_xx_w = numpy.dot(C_xx, w_i)
        converged, null_value = is_converged(C_xx_w, w_i, 10**(-12))
        if not converged:
            continue
        else:
            if not null_value:
                #computed Eigenvalue, take the first one
                BEST_EIGENVALUE = Eigenvalue(w_i, C_xx_w)
                print("Eigenvalue: " + str(BEST_EIGENVALUE))
                BEST_EIGENVECTOR = w_i
                break
            else:
                #Null-Eigenvalue
                BEST_EIGENVALUE = 0.0
                BEST_EIGENVECTOR = [0.0 for i in range(0, len(w_i))]
                break
    
    return (BEST_EIGENVECTOR, BEST_EIGENVALUE)


''' @param:  -X = list of input patterns
             -learn_rate
             -EV_minimum = breaks if EV_minimum is reached
    @return: triple (Eigenvectors, Eigenvalues, dimension) '''
def dimensioning(X, learn_rate):
    EVecs = list()
    EVals = list()
    new_X = copy.deepcopy(X)
    
    #compute auto correlation matrix)
    C_xx = AutoCorMatrix(new_X)
    
    #over all dimensions
    for i in range(0, len(X[0])):
        eigenvector, eigenvalue = Hebb_Iteration(new_X, [], C_xx, learn_rate)
        if eigenvalue < 10**(-12):
            print("null-eigenvalue")
            break
        
        EVecs.append(eigenvector.tolist())
        EVals.append(eigenvalue)
        
        new_X, null = reduceX(new_X, eigenvector)
        if null:
            return (EVecs, EVals, len(EVecs))
        
        C_xx = AutoCorMatrix(new_X)

    return (EVecs, EVals, len(EVecs))
    

def SangerNetwork(X, learn_rate):
    #start computing all stuff
    EVecs, EVals, dim = dimensioning(X, learn_rate)

    return (EVals, EVecs, dim)