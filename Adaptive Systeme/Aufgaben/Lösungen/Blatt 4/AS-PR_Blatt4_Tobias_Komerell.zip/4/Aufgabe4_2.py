"""#use python27"""
from PCA import SangerNetwork
from PCA import is_converged
from PCA import reduceX
from math import sqrt
from Algebra import *
from PIL import Image
import numpy

''' global variable for ICA input signal '''
ICA_SIGNAL = list()

'''
  @Author: tobias
   reads data from the images into ICA_SIGNAL
'''

def read_data():
    global ICA_SIGNAL
    ref1 = list(Image.open("reflection1.JPG").getdata())
    ref2 = list(Image.open("reflection2.JPG").getdata())
    #converting list of tuples to lists of lists
    for i in range(len(ref1)):
        ref1[i] = list(ref1[i]) 
    for i in range(len(ref2)):
        ref2[i] = list(ref2[i]) 
    
    #flatten the lists
    ref1 = numpy.array(ref1).flatten().tolist()
    ref2 = numpy.array(ref2).flatten().tolist()

    #removing background that is irrelevant for ICA
    refdiff = list()
    zeroedValues = 0
    for i in range(len(ref1)):
        if(abs(ref1[i] - ref2[i]) <= 6):
          #save the average of both to recreate the original later
          refdiff.append(int(0.5 * (ref1[i] + ref2[i])))
          #zero out the values in the input data
          ref1[i] = 0
          ref2[i] = 0
          zeroedValues += 1
        else:
          refdiff.append(0)

    print("%s values are so similar between the two inputs they have been zeroed out" % zeroedValues)
         
    
    refs = [ref1, ref2]
    for i in range(0, len(ref1)):
        V = list()
        for j in range(0, len(refs)):
            V.append(float(refs[j][i]))
        ICA_SIGNAL.append(V)
        
def ICA(X, eVals, eVecs):
    result_set = list()
    avg_X = MatrixAverage(X)
    cent_X = MatrixCentrate(X, avg_X)
    #Renomieren der Basisvektoren
    for i in range(0, len(eVals)):
        eVals[i] = 1.0/sqrt(eVals[i])
        eVecs[i] = VectorScalarMul(sqrt(eVals[i]), eVecs[i])
    #transform patterns
    V = list()
    for i in range(0, len(cent_X)):
        V.append(MatrixVectorMul(eVecs, cent_X[i]))
        
    #over all dimensions
    for k in range(0, len(V)):
        #fixpoint iteration
        w_i = [1.0 for x in range(0, len(eVecs[0]))]
        #replace with convergence criterium
        for i in range(0, 5):
            tmp = list()
            #Skalar und Weiteres..
            for j in range(0, len(V)):
                scalar = VectorScalarProduct(w_i, V[j])
                scalar = scalar**3
                result = VectorScalarMul(scalar, V[j])
                tmp.append(result)
            #Erwartungswert
            EW = copy.copy(tmp[0])
            for j in range(1, len(tmp)):
                EW = VectorAdd(EW, tmp[j])
            EW = VectorScalarMul(1.0/len(tmp), EW)
            sub = VectorSub(EW, VectorScalarMul(3.0, w_i))
            w_i = VectorNormalize(sub, 1.0)
       
        result_set.append(w_i)
        #reduce pattern space
        V = reduceX(V, w_i)
    return result_set
    
if __name__ == '__main__':
    #reading ica_signals.dt
    read_data()
    X = ICA_SIGNAL
    print("there are %s values for each of the two input images" % len(X)) 
    LEARN_RATE = 0.1
    eVals, eVecs, dim = SangerNetwork(X, LEARN_RATE, 1.0)
    result_set = ICA(X, eVals, eVecs)
    print(numpy.array(result_set))
    

    #write results to Ergebnisse_card1.txt
    fout = open("Ergebnisse_reflection.txt", "w")
    if fout:
        for i in range(0, len(result_set)):
            fout.write(str(result_set[i]) + "\n\n")
    fout.close()
