import copy
from math import sqrt

def MatrixVectorMul(M, V):
    tmp_V = list()
    for i in range(0, len(M)):
        tmp_V.append(VectorScalarProduct(M[i], V))
    return V

''' @param:  matrix with one column
    @return: corresponding vector    '''
def MatrixToVector(M):
    V = list()
    for i in range(0, len(M)):
        V.append(M[i][0])
    return V

''' @param:  two vectors
    @return: scalar product            '''
def VectorScalarProduct(X, Y):
    if len(X) != len(Y):
        print("[Scalar]: X and Y must have same size")
        return
    z = 0.0
    for i in range(0, len(X)):
        z += X[i]*Y[i]
    return z

''' @param:  scalar and vector
    @return: vector multiplied with the scalar        '''
def VectorScalarMul(y, X):
    V = list()
    for i in range(0, len(X)):
        V.append(y*X[i])
    return V

''' @param:  scalar and matrix
    @return: matrix multiplied with the scalar        '''
def MatrixScalarMul(y, M):
    rM = list()
    for i in range(0, len(M)):
        rM.append(list())
        for j in range(0, len(M[i])):
            rM[i].append(y*M[i][j])
    return rM

''' @param:  two vectors
    @return: corresponding matrix after vector         '''
def VectorMul(X, Y):
    M = list()
    for i in range(0, len(X)):
        M.append(list())
        for j in range(0, len(Y)):
            M[i].append(X[i]*Y[j])
    return M

''' @param:  two matrices
    @return: corresponding matrix after matrix product    '''
def MatrixMul(M_1, M_2):
    M = list()
    for i in range(0, len(M_1)):
        M.append(list())
        for j in range(0, len(M_2)):
            M[i].append(VectorScalarProduct(M_1[i], M_2[j]))
    return M

def VectorAdd(X, Y):
    if len(X) != len(Y):
        print("[Addition]: X and Y must have same size")
        return
    V = list()
    for i in range(0, len(X)):
        V.append(X[i]+Y[i])
    return V

def MatrixAdd(X, Y):
    M = list()
    for i in range(0, len(X)):
        M.append(list())
        for j in range(0, len(Y)):
            M[i].append(X[i][j] + Y[i][j])
    return M

def VectorSub(X, Y):
    if len(X) != len(Y):
        print("[Subtraction]: X and Y must have same size")
        return
    V = list()
    for i in range(0, len(X)):
        V.append(X[i]-Y[i])
    return V

def MatrixSub(X, Y):
    M = list()
    for i in range(0, len(X)):
        M.append(list())
        for j in range(0, len(Y)):
            M[i].append(X[i][j] - Y[i][j])
    return M

''' checks if family of vectors is pairwise quasi-orthogonal '''    
def isOrthogonal(EVs, error):
    for i in range(0, len(EVs)):
        for j in range(i+1, len(EVs)):
            scalar_value = 0.0
            for k in range(0, len(EVs[0])):
                scalar_value += EVs[i][k]*EVs[j][k]
            if abs(scalar_value) > error:
                print(str(abs(scalar_value)))
    return True

''' @param:  matrix M
    @return: average vector of M        '''
def MatrixAverage(M):
    V = copy.copy(M[0])
    for i in range(1, len(M)):
        V = VectorAdd(V, M[i])
    return VectorScalarMul(1.0/len(M), V)

''' @param:  matrix Vs, average vector avg_V
    @return: cencentrate vectors due to average vector '''
def MatrixCentrate(Vs, avg_V):
    centrated = list()
    for k in range(0, len(Vs)):
        centrated.append(VectorSub(Vs[k], avg_V))
    return centrated

def VectorNormalize(X, length):
    return VectorScalarMul(length/float(sqrt(VectorScalarProduct(X, X))), X)

def AutoCorMatrix(X):
    C_xx = VectorMul(X[0], X[0])
    for i in range(1, len(X)):
        C_xx = MatrixAdd(C_xx, VectorMul(X[i], X[i]))
    return MatrixScalarMul(1.0/len(X), C_xx) 

def Eigenvalue(EV, C_xx):
    C_xx_w = MatrixToVector(MatrixMul(C_xx, [EV]))
    return ((C_xx_w[0] / EV[0]), (C_xx_w[1] / EV[1]))