#use python 27

from math import sqrt
from Algebra import *

''' @param:  -C_xx = auto-correlation matrix
             -C_xx_w = product of w_i and C_xx
             -w_i = computed weights vector
             -delta = maximal error
    @return: - (True, -) if convered, (False, -) if not
             - (True, True) if Eigenvalue 0 is at hand '''
def is_converged(C_xx, C_xx_w, w_i, delta):
    dominator = sqrt(VectorScalarProduct(C_xx_w, C_xx_w))
    
    #means Null-Eigenvalue
    if dominator < delta:
        return (True, True)
    left_formula = VectorNormalize(C_xx_w, 1.0)
    #right_formula = w_i
    sub = VectorSub(left_formula, w_i)
    value = sqrt(VectorScalarProduct(sub, sub))

    if value < delta:
        return (True, False)
    return (False, False)


''' @param:  -X = list of patterns
             -w = approximated Eigenvector
    @return: -reduced list of patterns due to Eigenvector 
    see introduction for formula                            '''
def reduceX(X, w):
    new_X = list()
    for i in range(0, len(X)):
        new_X.append(list())
        scalar_product = VectorScalarProduct(X[i], w)
        scalar_mult = VectorScalarMul(scalar_product, w)
        vector_sub = VectorSub(X[i], scalar_mult)
        new_X[i] = vector_sub
    return new_X


''' @param:  -X = list of patterns
             -w_i (initially [])
             -C_xx = auto-correlation matrix
             -learn-rate
    @return: -tuple (Eigenvector, Eigenvalue) due to learning rule 
    see introduction for algorithm                                '''
BEST_EIGENVALUE = 0.0
BEST_EIGENVECTOR = list()

def Hebb_Iteration(X, w_i, C_xx, learn_rate):
    global BEST_EIGENVALUE
    global BEST_EIGENVECTOR
    
    #initial weight = 1^n
    if w_i == []:
        w_i = [1.0 for x in range(len(X[0]))]
    
    while True:
        #apply w_i_inc := w_i + learn_rate*(C_xx*w)
        C_xx_w = MatrixMul(C_xx, [w_i])
        C_xx_w = MatrixToVector(C_xx_w)
        w_i = VectorAdd(w_i, VectorScalarMul(learn_rate, C_xx_w))
        
        #normalize vector
        w_i =  VectorNormalize(w_i, 1.0)

        converged, null_value = is_converged(C_xx, C_xx_w, w_i, learn_rate)
        if not converged:
            continue
        else:
            if not null_value:
                #computed Eigenvalue, take the first one
                BEST_EIGENVALUE = Eigenvalue(w_i, C_xx)[0]
                print("Eigenvalue: " + str(BEST_EIGENVALUE))
                BEST_EIGENVECTOR = w_i
                break
            else:
                #Null-Eigenvalue
                BEST_EIGENVALUE = 0.0
                BEST_EIGENVECTOR = [0.0 for i in range(0, len(w_i))]
                break
    
    return (BEST_EIGENVECTOR, BEST_EIGENVALUE)


''' @param:  -X = list of input patterns
             -learn_rate
             -EV_minimum = breaks if EV_minimum is reached
    @return: triple (Eigenvectors, Eigenvalues, dimension) '''
def dimensioning(X, learn_rate, EV_minimum):
    EVecs = list()
    EVals = list()
    new_X = copy.copy(X)
    
    #compute auto correlation matrix
    avg_X = MatrixAverage(X)
    cent_X = MatrixCentrate(X, avg_X)
    C_xx = AutoCorMatrix(cent_X)
    
    #over all dimensions
    for i in range(0, len(X)):
        eigenvector, eigenvalue = Hebb_Iteration(new_X, [], C_xx, learn_rate)
        if eigenvalue == 0.0:
            break
        elif eigenvalue < EV_minimum:
            break

        EVecs.append(eigenvector)
        EVals.append(eigenvalue)
        
        new_X = reduceX(new_X, eigenvector)
        C_xx = AutoCorMatrix(new_X)
    
    return (EVecs, EVals, len(EVecs))

    

def SangerNetwork(X, learn_rate, minimal_ev=0.0):
    #start computing all stuff, breaks if Eigenvalue < 2.0 occures
    EVecs, EVals, dim = dimensioning(X, learn_rate, minimal_ev)

    return (EVals, EVecs, dim)
