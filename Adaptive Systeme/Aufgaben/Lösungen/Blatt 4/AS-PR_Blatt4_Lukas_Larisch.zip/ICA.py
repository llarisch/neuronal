#use python27
from math import sqrt
from PCA import reduceX
from Algebra import *
import numpy

def is_converged(w_i, last_w_i):
    val = 0.0
    for i in range(0, len(w_i)):
        if last_w_i[i] != 0:
            next_val = (w_i[i]/last_w_i[i])
            if 9.0*val/10.0 < next_val < 11.0*val/10.0:
                continue
            else:
                return False
        else:
            if val == 0.0:
                continue
            else:
                return False
    return True
    

    
def ICA(X, eVals, eVecs, dim):
    W = list()
    new_X = copy.deepcopy(X)
    
    #normalize eigenvectors & eigenvalues
    for i in range(0, len(eVals)):
        if eVals[i] == 0.0:
            continue
        eVals[i] = 1.0/sqrt(eVals[i])
        eVecs[i] = numpy.dot(eVals[i], eVecs[i])
    
    #transform patterns
    V = list()
    for i in range(0, len(new_X)):
        V.append(numpy.dot(eVecs, new_X[i]))
        
    new_V = copy.deepcopy(V)
    #over all dimensions
    for k in range(0, dim):
        #fixpoint iteration
        w_i = numpy.array([1.0 for x in range(0, len(V[0]))])
        #replace with convergence criterion
        #while not is_converged(w_i, last_w_i) and not begin:
        for i in range(0, 200):
            tmp = list()
            #scalar & co
            for j in range(0, len(new_V)):
                scalar = numpy.dot(w_i, new_V[j])
                scalar = scalar**3
                result = numpy.dot(scalar, new_V[j])
                tmp.append(result)
            #expectancy value
            EW = tmp[0]
            for j in range(1, len(tmp)):
                EW = numpy.add(EW, tmp[j])
            EW = numpy.dot(1.0/len(tmp), EW)
            w_i = numpy.subtract(EW, numpy.dot(3.0, w_i))

            #reduce w_i 
            for i in range(0, len(W)):
                w_i = numpy.subtract(w_i, numpy.dot(W[i], w_i)*W[i])

            #normalize w_i
            w_i = numpy.dot(1.0/sqrt(numpy.dot(w_i, w_i)), w_i)
       
        new_V, null = reduceX(new_V, w_i)
        W.append(w_i)

    return (numpy.array(W), numpy.array(new_V))