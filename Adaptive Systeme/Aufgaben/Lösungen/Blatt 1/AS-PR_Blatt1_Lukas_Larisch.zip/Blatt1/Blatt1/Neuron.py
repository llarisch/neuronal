import re


'''
formal neuron
'''
class Neuron(object):
    def __init__(self):
        self.__W = list()
        self.__S = None
        self.__z = float()
        
        self.__active = False
    
    '''
    configures the neuron
    params: W := vector of weights, floats
            S := output function
            I := inhibit value
            A := activated
    return: False if weights are not floats, otherwise True
    '''
    def setup_Neuron(self, W, S, I, A):
        regex_float = re.compile('^-?[0-9]+\.[0-9]+$')
        self.__W = list()
        for i in range(0, len(W)):
            if not regex_float.match(str(W[i])):
                print('[Neuron.setup_Neuron]: weights have to be floats!')
                return False
            self.__W.append(W[i])
        if not regex_float.match(str(I)):
            print('[Neuron.setup_Neuron]: inhibit value have to be a float!')
            return False
        self.__W.append(I)
        self.__S = S
        if not (str(A) == 'True' or str(A) == 'False'):
            print('[Neuron.setup_Neuron]: activation must be a boolean!')
            return False 
        self.__active = A
        return True

    '''
    computes z and S(z)
    params: X := input vector
    return: S(z)
    '''
    def work(self, X):
        self.__z = float()
        if not self.__active:
            print('[Neuron.work]: Neuron is not active!')
            return False
        if len(self.__W) == 0 or self.__S == None:
            print('[Neuron.work]: Neuron is not configurated!')
            return False
        if len(X)+1 != len(self.__W):
            print('[Neuron.work]: there have to be exactly ' + str(len(self.__W)) + ' inputs!')
            return False
        regex_float = re.compile('^-?[0-9]+\.[0-9]+$')
        for i in range(0, len(X)):
            if not regex_float.match(str(X[i])):
                print('[Neuron.work]: input vector must consist of floats!')
                self.__z = float()
                return False
            self.__z += (self.__W[i]*X[i])
        self.__z -= self.__W[-1]
        return self.__S(self.__z)
    
    ''' returns vector W of weights as a list '''
    def get_weights(self):
        return self.__W
    
    ''' setups vector W of weights given as a list '''
    def set_weights(self, W):
        regex_float = re.compile('^-?[0-9]+\.[0-9]+$')
        for i in range(0, len(W)):
            W[i] = round(W[i], 5)
            if not regex_float.match(str(W[i])):
                print(str(W))
                print('[Neuron.set_weights]: weights have to be floats!')
                return False
        self.__W = W
        return True
