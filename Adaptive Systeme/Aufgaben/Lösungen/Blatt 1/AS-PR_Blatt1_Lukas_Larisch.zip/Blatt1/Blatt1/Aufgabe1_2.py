from Neuron import *

WEIGHTS_OR = [1.0, 1.0]
WEIGHTS_AND = [1.0, 1.0]
WEIGHTS_NOT = [-1.0]
WEIGHTS_NAND = [-1.0, -1.0]
TEST_VECTOR = [[0.0, 0.0], #1
               [0.0, 1.0], #1
               [1.0, 0.0], #1
               [1.0, 1.0]] #0
           
if __name__ == '__main__':
    """
    OR
    """
    OR = Neuron()
    OR.setup_Neuron(WEIGHTS_OR, lambda x: 0 if x<=0 else 1, 0.0, True)
    print('OR')
    for i in range(0, len(TEST_VECTOR)):
        print('[' + str(TEST_VECTOR[i][0]) + ', ' + str(TEST_VECTOR[i][1]) + ']: ' + str(OR.work(TEST_VECTOR[i])))
    """
    AND
    """
    AND = Neuron()
    AND.setup_Neuron(WEIGHTS_AND, lambda x: 0 if x<=0 else 1, 1.90, True)
    print('AND')
    for i in range(0, len(TEST_VECTOR)):
        print('[' + str(TEST_VECTOR[i][0]) + ', ' + str(TEST_VECTOR[i][1]) + ']: ' + str(AND.work(TEST_VECTOR[i])))
    """
    NOT
    """
    NOT = Neuron()
    NOT.setup_Neuron(WEIGHTS_NOT, lambda x: 0 if x<=0 else 1, -0.01, True)
    print('NOT')
    print('[0.0]: ' + str(NOT.work([0.0])))
    print('[1.0]: ' + str(NOT.work([1.0])))
    """
    IMP
    """
    print('IMP')
    IMP = Neuron()
    for i in range(0, len(TEST_VECTOR)):
        IMP.setup_Neuron(WEIGHTS_OR, lambda x: 0 if x<=0 else 1, 0.0, True)
        value_not = float(NOT.work([TEST_VECTOR[i][0]]))
        print('[' + str(TEST_VECTOR[i][0]) + ', ' + str(TEST_VECTOR[i][1]) + ']: ' + str(IMP.work( [value_not, TEST_VECTOR[i][1]])))
    """
    NAND
    """
    print('NAND')
    NAND = Neuron()
    for i in range(0, len(TEST_VECTOR)):
        NAND.setup_Neuron(WEIGHTS_NAND, lambda x: 0 if x<=0 else 1, -1.9, True)
        print('[' + str(TEST_VECTOR[i][0]) + ', ' + str(TEST_VECTOR[i][1]) + ']: ' + str(NAND.work(TEST_VECTOR[i])))
    """
    XOR
    """
    print('XOR')
    XOR = Neuron()
    for i in range(0, len(TEST_VECTOR)):
        XOR.setup_Neuron(WEIGHTS_AND, lambda x: 0 if x<=0 else 1, 1.90, True)
        value_or = OR.work(TEST_VECTOR[i])
        value_nand = NAND.work(TEST_VECTOR[i])
        value_xor = AND.work([float(value_or), float(value_nand)])
        print('[' + str(TEST_VECTOR[i][0]) + ', ' + str(TEST_VECTOR[i][1]) + ']: ' + str(value_xor))

        
                                                                                      