import random

from Neuron import *
import matplotlib.pyplot as plt


WEIGHTS = [-4.6, 3.7]
           
if __name__ == '__main__':
    N = Neuron()
    N.setup_Neuron(WEIGHTS, lambda x: x, 0.0, True)
    
    #generate ten random points
    Sample = random.sample([x for x in range(0, 10)], 10)
    for i in range(0, 10):
        value = N.work([float(i), float(Sample[i])])
        if value <= 0:
            plt.plot(i, Sample[i], 'go')
        else:
            plt.plot(i, Sample[i], 'ro')
    
    #compute straight line
    W = N.get_weights()
    G_x = list()
    G_y = list()
    for i in range(0, 10):
        G_x.append(i)
        G_y.append(i*(-W[0]/W[1]))
    
    #plot straight line
    plt.plot(G_x, G_y)
    plt.axis([0, 10, 0, 10])
    plt.show()