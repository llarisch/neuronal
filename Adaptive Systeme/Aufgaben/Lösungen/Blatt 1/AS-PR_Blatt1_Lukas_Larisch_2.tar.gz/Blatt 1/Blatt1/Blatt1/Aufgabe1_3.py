from Perceptron import *
import matplotlib.patches as mpatches
import matplotlib.pyplot as plt


TRAINING_VECTOR = [[4.9, 3.0, 0],
                   [4.7, 3.2, 0],
                   [5.1, 3.5, 0],
                   [4.6, 3.1, 0],
                   [5.0, 3.6, 0],
                   [5.4, 3.9, 0],
                   [4.6, 3.4, 0],
                   [6.3, 3.3, 1],
                   [5.8, 3.3, 1],
                   [7.1, 3.0, 1],
                   [6.3, 2.9, 1],
                   [6.5, 3.0, 1],
                   [7.6, 3.0, 1],
                   [4.9, 2.5, 1]
                   ]

NEW_INSTANCES = [[5.1, 3.3],
                 [5.9, 3.0],
                 [5.7, 2.5],
                 [5.4, 3.7]]
    

    
if __name__ == '__main__':
    P = Perceptron()
    P.setup_Neuron([0.0, 0.0], lambda x: 0 if x<=0 else 1, 0.0, True)
    #train the perceptron with TRAINING_VECTOR, 50 iterations over all training data
    for k in range(0, 50):
        for i in range(0, len(TRAINING_VECTOR)):
            P.training(TRAINING_VECTOR[i][:2], TRAINING_VECTOR[i][2])
    
    #plot training data
    for i in range(0, len(TRAINING_VECTOR)):
        plt.plot(TRAINING_VECTOR[i][0], TRAINING_VECTOR[i][1], 'go')    
    
    #plot unclassified data    
    for i in range(0, len(NEW_INSTANCES)):
        plt.plot(NEW_INSTANCES[i][0], NEW_INSTANCES[i][1], 'ro')
    
    #compute straight line
    W = P.get_weights()
    G_x = list()
    G_y = list()
    for i in range(4, 9):
        G_x.append(i)
        G_y.append(i*(-W[0]/W[1]))
    
    #plot straight line
    plt.plot(G_x, G_y)
    plt.axis([4, 8, 2, 5])
    plt.xlabel("attribute 1")
    plt.ylabel("attribute 2")

    b1 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='green')
    b2 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='red')
    plt.legend([b1, b2], ["classified points", "unclassified points"])
    plt.show()
    