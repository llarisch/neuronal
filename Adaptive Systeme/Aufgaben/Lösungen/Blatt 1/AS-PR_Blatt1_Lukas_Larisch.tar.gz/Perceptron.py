from Neuron import *
import re


'''
a perceptron
'''
class Perceptron(Neuron):
    def __init__(self):
        Neuron.__init__(self)
        self.setup_Neuron([0.0, 0.0], lambda x: 0 if x<=0 else 1, 0.0, True)
        self.__learn_rate = 0.1
    '''
    implements the perceptron-learning-algorithm   
    input:  instance X [list], teachers value L [float]
    return: True if perceptron has been taught, else False
    '''
    def training(self, X, L):
        y = self.work(X)
        if y != L:
            weights = self.get_weights()
            if y < L:
                for i in range(0, len(X)):
                    weights[i] += self.__learn_rate*X[i]
                weights[-1] -= self.__learn_rate*weights[-1]
            else:
                for i in range(0, len(X)):
                    weights[i] -= self.__learn_rate*X[i]
                weights[-1] += self.__learn_rate*weights[-1]
            self.set_weights(weights)
            #print("X=" + str(X) + ", L=" + str(L) + ", new_W=" + str(weights))
            return True
            
        return False

    '''
    change the learning rate
    '''
    def set_learning_rate(self, new_rate):
        regex_float = re.compile('^-?[0-9]+\.[0-9]+$')
        if not regex_float.match(str(new_rate)):
            print("[Perceptron.set_learning_rate]: new learning rate must be a float!")
            return False
        self.__learn_rate = new_rate
        return True