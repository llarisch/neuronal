from scipy import ndimage
from scipy import misc
import sys

import Adaline
import matplotlib.pyplot as plt
from numpy.lib.stride_tricks import as_strided as ast
import numpy
    

def read_image(dest):
    image = misc.imread(dest)
    height = image.shape[0]
    width = image.shape[1]
    
    print("loaded image " + str(dest))
    print("image height: " + str(height))
    print("image width: " + str(width))
    print("pixels count: " + str(height*width) + "\n")
    
    return numpy.array(image), width, height 

    image_blurred = ndimage.gaussian_filter(image, sigma=0)
    plt.imshow(image_blurred)

def print_image(image):
    plt.imshow(image)
    plt.show()
    

def get_block(image, x, y, block_size, component):
    block = image[x:x+block_size, y:y+block_size]
    new_block = list()
    for i in range(0, len(block)):
        for j in range(0, len(block[i])):
            new_block.append(block[i][j][component])

    #returns the block with radius lower_gauss(block_size/2) and the mid element
    #assumes block_size is odd
    return new_block, new_block[(block_size**2/2)]

    
def get_blocks(image, range_x, range_y, block_size, component):
    blocks = list()
    L = list()
    for i in range(0, range_x-block_size):
        for j in range(0, range_y-block_size):
            block, mid = get_block(image, i, j, block_size, component)
            blocks.append(block)
            L.append(mid)
    return blocks, L

def print_blocks(blocks, dir, filename, format):
    for i in range(0, len(blocks)):
        try:
            misc.imsave(dir+filename+'_'+str(i)+'.'+format, blocks[i])
        except:
            print(str(i))

def training():
    print("loading image data")
    
    image, width, height = read_image('training.jpg')
    blocks_orig, L_orig = get_blocks(image, height, width, 3, 0)
    print(str(len(blocks_orig)) + " blocks from training.jpg loaded\n")
    
    image_blurred, width_blurred, height_blurred = read_image('training_blurred.jpg')
    blocks_blurred, L_blurred = get_blocks(image_blurred, height, width, 3, 0)
    print(str(len(blocks_orig)) + " blocks from training_blurred.jpg loaded\n")
    
    print("begin of training\n")
    
    A = Adaline.Adaline(1, 9, lambda x: 1 if x >= 0 else -1, 0.1)

    ''' regular input '''
    #count of iterations
    for i in range(0, 1):
        #for all blocks
        for j in range(0, len(L_orig)):
            A.work(blocks_blurred[i], L_orig[i])
            
    print("end of training\n")
    
    print("---W---")
    print(str(A.get_weights_matrix()) + "\n")
    
    return A
        #regular_digit.append(Digits[i])
        #noisy_digit.append(make_noisy(Digits[i], 0.1))
        #output_digit.append(A.read(noisy_digit[-1]))

if __name__ == '__main__':
    
    W1 = [[-0.1, -0.2, -0.1, 
           -0.2,  1.2, -0.2, 
           -0.1, -0.2, -0.1]]
    
    W2 = [[0.0, -1.0,  0.0,
          -1.0,  5.0, -1.0,
           0.0, -1.0,  0.0]]
           
    W3 = [[  0.0, -0.25,   0.0,
           -0.25,     2, -0.25,
             0.0, -0.25,   0.0]]
    
    BLOCK_SIZE = 3
    IMAGE = 'adaline_lego.jpg'
    #IMAGE = 'training_blurred.jpg'
    
    
    #AdalineInstance = training()
    
    AdalineInstance = Adaline.Adaline(1, BLOCK_SIZE**2, lambda x: 1 if x >= 0 else -1, 0.1)

    AdalineInstance.set_weights_matrix(W3)

    image, width, height = read_image(IMAGE)
    blocks_comp1, L= get_blocks(image, height, width, BLOCK_SIZE, 0)
    
    print(str(len(blocks_comp1)) + " blocks from " + IMAGE + " loaded [comp1]\n")
    
    blocks_comp2, L= get_blocks(image, height, width, BLOCK_SIZE, 1)
    
    print(str(len(blocks_comp2)) + " blocks from " + IMAGE + " loaded [comp2]\n")
    
    blocks_comp3, L= get_blocks(image, height, width, BLOCK_SIZE, 2)
    
    print(str(len(blocks_comp3)) + " blocks from " + IMAGE + " loaded [comp3]\n")
    
    Result = list()
    
    for i in range(0, len(blocks_comp1)):
        Result.append([AdalineInstance.read(blocks_comp1[i]), AdalineInstance.read(blocks_comp2[i]), AdalineInstance.read(blocks_comp3[i])])

    print("resulting image computed")
        
    #rearranging results to 2-dim
    Result = numpy.array(Result).reshape(height-BLOCK_SIZE, width-BLOCK_SIZE, 3)
    print_image(image)
    print_image(Result)
    
    