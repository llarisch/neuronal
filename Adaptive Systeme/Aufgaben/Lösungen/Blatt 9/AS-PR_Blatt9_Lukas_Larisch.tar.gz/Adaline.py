import numpy
import sys

''' an adaline '''
class Adaline(object):
    def __init__(self, max_m, max_n, S, learn_rate=0.1):
        self.__W = numpy.zeros(max_n*max_m).reshape(max_n, max_m)
        
        self.__N = max_n
        self.__M = max_m
        self.__learn_rate = learn_rate
        self.__S = S
    
    ''' -calculates neural network activity 
        -learns from input X and L, given as lists of floats
        -returns False if an error occured, else True '''
    def work(self, X, L):
        x2 = numpy.dot(X,X)

        #activity
        z = numpy.dot(self.__W, X)
        partial_solution = self.__learn_rate*(z-L)/x2

        #learning
        for i in range(0, self.__N):
            for j in range(0, self.__M):
                #self.__W[i][j] -= self.__learn_rate*(z-L)*X[j]/x2
                self.__W[i][j] -= X[j]*partial_solution
        
        return True
    
    ''' calculates and returns network output with respect to X, given 
        as a list of floats 
        returns a list of floats '''
    def read(self, X):
        output = list()
        for i in range(0, len(self.__W)):
            z = numpy.dot(X, self.__W[i])
            z = self.__S(z)
            output.append(z)   
        return output
        
    def get_weights_matrix(self):
        return self.__W
    
    def set_weights_matrix(self, W):
        self.__W = numpy.array(W)