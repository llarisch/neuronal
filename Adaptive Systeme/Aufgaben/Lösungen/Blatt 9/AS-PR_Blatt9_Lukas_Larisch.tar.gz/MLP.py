import numpy
import math
import random

class MLP(object):
    def __init__(self, n, p, m, learn_rate):
        self.n = n
        self.p = p
        self.m = m
        
        self.W1 = list()
        self.W2 = list()
        self.deltaW1 = list()
        self.deltaW2 = list()
        
        self.X1 = [0.0 for n in range(0, self.n+1)]
        self.X2 = [0.0 for p in range(0, self.p+1)]
        
        self.y2 = list()
        self.d2 = list()
        
        self.bias1 = 0.0
        self.bias2 = 1.0
        
        for i in range(0, self.p):
            self.W1.append(list())
            self.deltaW1.append(list())
            self.W1[i].append(self.bias1)
            self.deltaW1[i].append(0.0)
            for j in range(0, self.n):
                self.W1[i].append(float(random.randint(-100, 100))/100.0)
                self.deltaW1[i].append(0.0)
        
        for i in range(0, self.m):
            self.W2.append(list())
            self.deltaW2.append(list())
            self.W2[i].append(self.bias2)
            self.deltaW2[i].append(0.0)
            for j in range(0, self.p):
                self.W2[i].append(float(random.randint(-100, 100))/100.0)
                self.deltaW2[i].append(0.0)
            
            self.y2.append(0.0)
            self.d2.append(0.0)
            
        self.S1 = lambda x: 1.0/(1.0+math.exp(-x))
        self.dS1 = lambda x: (1.0 - self.S1(x))*self.S1(x)
        
        self.S2 = lambda x: x
        self.dS2 = lambda x: 1.0
        
        self.errors_second_layer = list()
        
        self.learn_rate = learn_rate
        
        self.saved_W1 = list()
        self.saved_W2 = list()
        
    def readPattern(self, X):
        self.X1[0] = 1.0
        for i in range(0, self.n):
            self.X1[i+1] = X[i]
        
    def training(self, X, L):
        for i in range(0, self.m):
            for j in range(0, self.p+1):
                self.deltaW2[i][j] = 0.0
        for i in range(0, self.p):
            for j in range(0, self.n+1):
                self.deltaW1[i][j] = 0.0
        
        self.readPattern(X)
        
        #output hidden layer
        self.Z1 = list()
        self.X2[0] = self.bias2
        for i in range(0, self.p):
            self.Z1.append(numpy.dot(self.W1[i], self.X1))
            self.X2[i+1] = self.S1(self.Z1[i])
        
        #output and error second layer
        self.errors_second_layer.append(0.0)
        
        for i in range(0, self.m):
            self.y2[i] = self.S2(numpy.dot(self.W2[i], self.X2))
            self.d2[i] = -(self.y2[i]-L[i])*self.dS2(self.y2[i])
            
            self.errors_second_layer[-1] += (self.y2[i]-L[i])**2
        self.errors_second_layer[-1] = math.sqrt(self.errors_second_layer[-1])
        
        
        #improve weights second layer
        for i in range(0, self.m):
            for j in range(0, self.p+1):
                self.deltaW2[i][j] += self.learn_rate*self.d2[i]*self.X2[j]
                
        
        def SumProd(i):
            value = 0.0
            for k in range(0, self.m):
                value += self.d2[k] * self.W2[k][i]
            return value

        #improve weights first layer
        for i in range(0, self.p):
            for j in range(0, self.n+1):
                self.deltaW1[i][j] += self.learn_rate*SumProd(i+1)*self.dS1(self.Z1[i])*self.X1[j]
                #print(str(SumProd(i+1)) + " * " + str(self.dS1(self.Z1[i])) + " * " + str(self.X1[j]) + " = " + str(self.deltaW1[i][j]))
        
        for i in range(0, self.p):
            for j in range(0, self.n+1):
                self.W1[i][j] += self.deltaW1[i][j]
                
        for i in range(0, self.m):
            for j in range(0, self.p+1):
                self.W2[i][j] += self.deltaW2[i][j]
    
        
    def output(self, X, saved=False):
        self.readPattern(X)
        
        self.X2[0] = self.bias2
        
        if not saved:
            for i in range(0, self.p):
                self.X2[i+1] = self.S1(numpy.dot(self.W1[i], self.X1))
    
            for i in range(0, self.m):
                self.y2[i] = self.S2(numpy.dot(self.W2[i], self.X2))
        else:
            for i in range(0, self.p):
                self.X2[i+1] = self.S1(numpy.dot(self.saved_W1[i], self.X1))
    
            for i in range(0, self.m):
                self.y2[i] = self.S2(numpy.dot(self.saved_W2[i], self.X2))

        return self.y2
    
    def save_weights(self):
        self.saved_W1 = self.W1
        self.saved_W2 = self.W2
        
    def print_weights(self):
        print(str(self.saved_W1))
        print(str(self.saved_W2))
