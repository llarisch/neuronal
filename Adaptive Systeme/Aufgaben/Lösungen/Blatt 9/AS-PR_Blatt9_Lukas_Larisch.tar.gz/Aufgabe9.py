#use python27
import Adaline
import MLP
import Plotting
import random

errorHistory = list()

sensor_data = list()
usage_data = list()

sensor_validation_data = list()
usage_validation_data = list()
validation_index = list()

prediction_data = list()
real_data = list()

def read_sensor_data(dest):
    fin = open(dest, 'r')
    for line in fin:
        line = line.replace('\r', '')
        line = line.replace('\n', '')
        line = line.split(' ')
        sensor_data.append(list())
        for i in range(0, len(line)):
            sensor_data[-1].append(float(line[i]))
            
def read_usage_data(dest):
    fin = open(dest, 'r')
    for line in fin:
        line = line.replace('\r', '')
        line = line.replace('\n', '')
        line = line.split(' ')
        usage_data.append(list())
        for i in range(0, len(line)):
            usage_data[-1].append(float(line[i]))
            
def read_prediction_data(dest):
    fin = open(dest, 'r')
    for line in fin:
        line = line.replace('\r', '')
        line = line.replace('\n', '')
        line = line.split(' ')
        prediction_data.append(list())
        for i in range(0, len(line)):
            prediction_data[-1].append(float(line[i]))
            
def read_real_data(dest):
    fin = open(dest, 'r')
    for line in fin:
        line = line.replace('\r', '')
        line = line.replace('\n', '')
        line = line.split(' ')
        real_data.append(list())
        for i in range(0, len(line)):
            real_data[-1].append(float(line[i]))
            
def results_to_dt(dest, results):
    fout = open(dest, 'w')
    for i in range(0, len(results)):
        for j in  range(0, len(results[i])):
            fout.write(str(results[i][j]) + " ")
        fout.write("\n")
            
    
def compare_prediction_with_real_data(prediction, real_data):
    counter = 0
    abs_error = 0.0
    for i in range(0, len(prediction)):
        abs_error += abs(real_data[i][0]-prediction[i][0])
        abs_error += abs(real_data[i][1]-prediction[i][1])
        abs_error += abs(real_data[i][2]-prediction[i][2])
        counter += 3
    abs_error = abs_error/float(counter)
    return abs_error
    
def make_validation_data(procent=10):
    pattern_size = len(sensor_data)
    validation_size = procent*(pattern_size/100)
    for i in range(0, validation_size):
        rnd = random.randint(0, pattern_size-1)
        if rnd in validation_index:
            i -= 1
            continue
        
        sensor_validation_data.append(sensor_data[rnd])
        usage_validation_data.append(usage_data[rnd])
        validation_index.append(rnd)
      
def use_adaline():
    Adaline_Instance_Energy = Adaline.Adaline(4, 1, lambda x: x)
    Adaline_Instance_Cold_Water = Adaline.Adaline(4, 1, lambda x: x)
    Adaline_Instance_Hot_Water = Adaline.Adaline(4, 1, lambda x: x)
    
    for epoche in range(0, 50):
        rnd_idx = [i for i in range(0, len(sensor_data))]
        random.shuffle(rnd_idx)
        print(str(epoche))
        for i in range(0, len(sensor_data)):
            Adaline_Instance_Energy.work(sensor_data[rnd_idx[i]], usage_data[rnd_idx[i]][0])
            Adaline_Instance_Cold_Water.work(sensor_data[rnd_idx[i]], usage_data[rnd_idx[i]][1])
            Adaline_Instance_Hot_Water.work(sensor_data[rnd_idx[i]], usage_data[rnd_idx[i]][2])
            
    output_adaline = list()
    
    for i in range(0, len(sensor_data)):
        Data = [Adaline_Instance_Energy.read(sensor_data[i]), Adaline_Instance_Cold_Water.read(sensor_data[i]), Adaline_Instance_Hot_Water.read(sensor_data[i])]
        output_adaline.append(Data)
    
    prediction = list()
    
    for i in range(0, len(prediction_data)):
        Data = [Adaline_Instance_Energy.read(prediction_data[i])[0], Adaline_Instance_Cold_Water.read(prediction_data[i])[0], Adaline_Instance_Hot_Water.read(prediction_data[i])[0]]
        prediction.append(Data)
        
    #plot_prediction_weekly(prediction)
    
    compare_prediction_with_real_data(prediction, real_data)

    #results_to_dt("building_week17-20_enrg.dt", prediction)
    

def use_mlp(epoches=100, validation_time=10, hidden_neurons_energy=3, hidden_neurons_cold_water=2, hidden_neurons_hot_water=2, \
            use_validation_data = False, plot = True):
    MLP_Instance_Energy = MLP.MLP(4, hidden_neurons_energy, 1, learn_rate=0.1)
    MLP_Instance_Cold_Water = MLP.MLP(4, hidden_neurons_cold_water, 1, learn_rate=0.1)
    MLP_Instance_Hot_Water = MLP.MLP(4, hidden_neurons_hot_water, 1, learn_rate=0.1)
    
    minimum_error = float('inf')
    
    """ epoches count """
    for epoche in range(0, epoches):
        rnd_idx = [i for i in range(0, len(sensor_data))]
        random.shuffle(rnd_idx)
        print(str(epoche))
        #training with all pattern
        for i in range(0, len(sensor_data)):
            if not use_validation_data:
                if i in validation_index:
                    continue
            MLP_Instance_Energy.training(sensor_data[rnd_idx[i]], [usage_data[rnd_idx[i]][0]])
            MLP_Instance_Cold_Water.training(sensor_data[rnd_idx[i]], [usage_data[rnd_idx[i]][1]])
            MLP_Instance_Hot_Water.training(sensor_data[rnd_idx[i]], [usage_data[rnd_idx[i]][2]])
            if (20 <= rnd_idx[i] % 168) <= 80:
                MLP_Instance_Energy.training(sensor_data[rnd_idx[i]], [usage_data[rnd_idx[i]][0]])
            
        """ save weights if error has improved """
        if ((epoche+1) % validation_time == 0):
            prediction = list()
            for i in range(0, len(sensor_validation_data)):
                Data = [MLP_Instance_Energy.output(sensor_validation_data[i])[0], MLP_Instance_Cold_Water.output(sensor_validation_data[i])[0], MLP_Instance_Hot_Water.output(sensor_validation_data[i])[0]]
                prediction.append(Data)
            
            current_error = compare_prediction_with_real_data(prediction, usage_validation_data)
            print("error: " + str(current_error))
            errorHistory.append(current_error)
            if(current_error < minimum_error):
                minimum_error = current_error
                MLP_Instance_Energy.save_weights()
                MLP_Instance_Cold_Water.save_weights()
                MLP_Instance_Hot_Water.save_weights()
                print("error improved!")

    """ compute mlp output on learn pattern """
    mlp_results = list()
    
    for i in range(0, len(sensor_data)):
        Data = [MLP_Instance_Energy.output(sensor_data[i])[0], MLP_Instance_Cold_Water.output(sensor_data[i])[0], MLP_Instance_Hot_Water.output(sensor_data[i])[0]]
        mlp_results.append(Data)
        
    if plot:
        Plotting.plot_results_weekly_energy(mlp_results, usage_data, 0, 20)
        Plotting.plot_results_weekly_cold_water(mlp_results, usage_data, 0, 20)
        Plotting.plot_results_weekly_hot_water(mlp_results, usage_data, 0, 20)
    
    """ summarise prognostication """
    prediction = list()
    
    for i in range(0, len(prediction_data)):
        Data = [MLP_Instance_Energy.output(prediction_data[i])[0], MLP_Instance_Cold_Water.output(prediction_data[i])[0], MLP_Instance_Hot_Water.output(prediction_data[i])[0]]
        prediction.append(Data)
        
    return prediction


if __name__ == '__main__':
    read_sensor_data("building_week01-12_sens.dt")
    read_usage_data("building_week01-12_enrg.dt")
    read_sensor_data("building_week13-16_sens.dt")
    read_usage_data("building_week13-16_enrg.dt")
    read_sensor_data("building_week17-20_sens.dt")
    read_usage_data("building_week17-20_enrg.dt")
    read_prediction_data("building_week21-25_sens.dt")
    #read_real_data("building_week17-20_enrg.dt")
    
    make_validation_data(procent=10)
    
    #use_adaline()
    prediction = use_mlp(epoches=500, validation_time=5, \
                         hidden_neurons_energy=5, hidden_neurons_cold_water=3, hidden_neurons_hot_water=3, \
                         use_validation_data = False, plot = True)
    
    Plotting.plot_prediction_weekly(prediction)
    
    #prediction_error = compare_prediction_with_real_data(prediction, real_data)
    #print("prediction error:" + str(prediction_error))
    results_to_dt("building_week21-25_enrg.dt", prediction)
    
    Plotting.plot_error_history(errorHistory)