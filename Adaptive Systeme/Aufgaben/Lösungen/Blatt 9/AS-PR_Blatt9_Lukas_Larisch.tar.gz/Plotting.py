import matplotlib.pyplot as plt

def plot_temperature(sensor_data):
    plt.plot([i for i in range(0, len(sensor_data))], [sensor_data[i][0] for i in range(0, len(sensor_data))])
    plt.axis([0, len(sensor_data), 0, 1])
    b1 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='blue')
    plt.legend([b1], ["temperatur"])
    plt.show()
    
def plot_humidity(sensor_data):
    plt.plot([i for i in range(0, len(sensor_data))], [sensor_data[i][1] for i in range(0, len(sensor_data))])
    plt.axis([0, len(sensor_data), 0, 1])
    b1 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='blue')
    plt.legend([b1], ["humidity"])
    plt.show()
    
def plot_radiation(sensor_data):
    plt.plot([i for i in range(0, len(sensor_data))], [sensor_data[i][2] for i in range(0, len(sensor_data))])
    plt.axis([0, len(sensor_data), 0, 1])
    b1 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='blue')
    plt.legend([b1], ["radiation"])
    plt.show()
    
def plot_wind_velocity(sensor_data):
    plt.plot([i for i in range(0, len(sensor_data))], [sensor_data[i][3] for i in range(0, len(sensor_data))])
    plt.axis([0, len(sensor_data), 0, 1])
    b1 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='blue')
    plt.legend([b1], ["wind velocity"])
    plt.show()
    
def plot_energy(usage_data):
    plt.plot([i for i in range(0, len(usage_data))], [usage_data[i][0] for i in range(0, len(usage_data))])
    plt.axis([0, len(usage_data), 0, 1])
    b1 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='blue')
    plt.legend([b1], ["energy"])
    plt.show()

def plot_cold_water(usage_data):
    plt.plot([i for i in range(0, len(usage_data))], [usage_data[i][1] for i in range(0, len(usage_data))])
    plt.axis([0, len(usage_data), 0, 1])
    b1 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='blue')
    plt.legend([b1], ["cold water"])
    plt.show()

def plot_hot_water(usage_data):
    plt.plot([i for i in range(0, len(usage_data))], [usage_data[i][2] for i in range(0, len(usage_data))])
    plt.axis([0, len(usage_data), 0, 1])
    b1 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='blue')
    plt.legend([b1], ["hot water"])
    plt.show()
    
def plot_weekly(sensor_data, usage_data):
    week = 12
    plt.plot([i for i in range(0, len(sensor_data)/week)], [sensor_data[i][0] for i in range(0, len(sensor_data)/week)], 'pink')
    plt.plot([i for i in range(0, len(sensor_data)/week)], [sensor_data[i][1] for i in range(0, len(sensor_data)/week)], 'grey')
    plt.plot([i for i in range(0, len(sensor_data)/week)], [sensor_data[i][2] for i in range(0, len(sensor_data)/week)], 'black')
    plt.plot([i for i in range(0, len(sensor_data)/week)], [sensor_data[i][3] for i in range(0, len(sensor_data)/week)], 'yellow')
    plt.plot([i for i in range(0, len(usage_data)/week)], [usage_data[i][0] for i in range(0, len(usage_data)/week)], 'red')
    plt.plot([i for i in range(0, len(usage_data)/week)], [usage_data[i][1] for i in range(0, len(usage_data)/week)], 'green')
    plt.plot([i for i in range(0, len(usage_data)/week)], [usage_data[i][2] for i in range(0, len(usage_data)/week)], 'blue')
    plt.axis([0, len(usage_data)/week, 0, 1])
    b1 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='pink')
    b2 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='grey')
    b3 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='black')
    b4 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='yellow')
    b5 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='red')
    b6 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='green')
    b7 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='blue')
    plt.legend([b1,b2,b3,b4,b5,b6,b7], ["temperature", "humidity", "radiation", "wind velocity", "energy", "cold water", "hot water"])
    plt.show()
    
    
def plot_results_weekly_energy(results, usage_data, week_min, week_max):
    weekhours = 7*24
    for week in range(week_min, week_max):
        plt.plot([i for i in range(week*weekhours, (week+1)*weekhours)], [results[i][0] for i in range(week*weekhours, (week+1)*weekhours)], 'blue') 
        plt.plot([i for i in range(week*weekhours, (week+1)*weekhours)], [usage_data[i][0] for i in range(week*weekhours, (week+1)*weekhours)], 'green')
        b1 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='blue')
        b2 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='green')
        plt.legend([b1,b2], ["network energy",  "real energy"])
        plt.axis([week*weekhours, (week+1)*weekhours, 0, 1])
        plt.show()
        
def plot_results_weekly_cold_water(results, usage_data, week_min, week_max):
    weekhours = 7*24
    for week in range(week_min, week_max):
        plt.plot([i for i in range(week*weekhours, (week+1)*weekhours)], [results[i][1] for i in range(week*weekhours, (week+1)*weekhours)], 'pink')
        plt.plot([i for i in range(week*weekhours, (week+1)*weekhours)], [usage_data[i][1] for i in range(week*weekhours, (week+1)*weekhours)], 'brown')
        b1 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='pink')
        b2 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='brown')
        plt.legend([b1,b2,], ["network cold water", "real cold water"])
        plt.axis([week*weekhours, (week+1)*weekhours, 0, 1])
        plt.show()

def plot_results_weekly_hot_water(results, usage_data, week_min, week_max):
    weekhours = 7*24
    for week in range(week_min, week_max):
        plt.plot([i for i in range(week*weekhours, (week+1)*weekhours)], [results[i][2] for i in range(week*weekhours, (week+1)*weekhours)], 'grey')
        plt.plot([i for i in range(week*weekhours, (week+1)*weekhours)], [usage_data[i][2] for i in range(week*weekhours, (week+1)*weekhours)], 'red')
        b1 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='grey')
        b2 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='red')
        plt.legend([b1,b2,], ["network hot water", "real hot water"])
        plt.axis([week*weekhours, (week+1)*weekhours, 0, 1])
        plt.show()
        
def plot_prediction_weekly(prediction):
    weekhours = 7*24
    for week in range(0, 4):
        plt.plot([i for i in range(week*weekhours, (week+1)*weekhours)], [prediction[i][0] for i in range(week*weekhours, (week+1)*weekhours)], 'red')
        plt.plot([i for i in range(week*weekhours, (week+1)*weekhours)], [prediction[i][1] for i in range(week*weekhours, (week+1)*weekhours)], 'green')
        plt.plot([i for i in range(week*weekhours, (week+1)*weekhours)], [prediction[i][2] for i in range(week*weekhours, (week+1)*weekhours)], 'blue')
        b1 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='red')
        b2 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='green')
        b3 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='blue')
        plt.legend([b1,b2,b3], ["prediction energy", "prediction cold water", "prediction hot water"])
        plt.axis([week*weekhours, (week+1)*weekhours, 0, 1])
        plt.show()
        
def plot_comparison_weekly_all(prediction, real_data):
    weekhours = 7*24
    for week in range(0, 4):
        plt.plot([i for i in range(week*weekhours, (week+1)*weekhours)], [prediction[i][0] for i in range(week*weekhours, (week+1)*weekhours)], 'red')
        plt.plot([i for i in range(week*weekhours, (week+1)*weekhours)], [prediction[i][1] for i in range(week*weekhours, (week+1)*weekhours)], 'green')
        plt.plot([i for i in range(week*weekhours, (week+1)*weekhours)], [prediction[i][2] for i in range(week*weekhours, (week+1)*weekhours)], 'blue')
        plt.plot([i for i in range(week*weekhours, (week+1)*weekhours)], [real_data[i][0] for i in range(week*weekhours, (week+1)*weekhours)], 'grey')
        plt.plot([i for i in range(week*weekhours, (week+1)*weekhours)], [real_data[i][1] for i in range(week*weekhours, (week+1)*weekhours)], 'pink')
        plt.plot([i for i in range(week*weekhours, (week+1)*weekhours)], [real_data[i][2] for i in range(week*weekhours, (week+1)*weekhours)], 'brown')
        b1 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='red')
        b2 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='green')
        b3 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='blue')
        b4 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='grey')
        b5 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='pink')
        b6 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='brown')
        plt.legend([b1,b2,b3,b4,b5,b6], ["prediction energy", "prediction cold water", "prediction hot water", "real energy", "real cold water", "real hot water"])
        plt.axis([week*weekhours, (week+1)*weekhours, 0, 1])
        plt.show()
        
def plot_comparison_weekly_single(prediction, real_data):
    weekhours = 7*24
    for week in range(0, 4):
        plt.plot([i for i in range(week*weekhours, (week+1)*weekhours)], [prediction[i][0] for i in range(week*weekhours, (week+1)*weekhours)], 'red')
        plt.plot([i for i in range(week*weekhours, (week+1)*weekhours)], [real_data[i][0] for i in range(week*weekhours, (week+1)*weekhours)], 'blue')
        b1 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='red')
        b2 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='blue')
        plt.legend([b1,b2], ["prediction energy", "real energy"])
        plt.axis([week*weekhours, (week+1)*weekhours, 0, 1])
        plt.show()
    
    for week in range(0, 4):
        plt.plot([i for i in range(week*weekhours, (week+1)*weekhours)], [prediction[i][1] for i in range(week*weekhours, (week+1)*weekhours)], 'red')
        plt.plot([i for i in range(week*weekhours, (week+1)*weekhours)], [real_data[i][1] for i in range(week*weekhours, (week+1)*weekhours)], 'blue')
        b1 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='red')
        b2 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='blue')
        plt.legend([b1,b2], ["prediction cold water", "real cold water"])
        plt.axis([week*weekhours, (week+1)*weekhours, 0, 1])
        plt.show()
        
    for week in range(0, 4):
        plt.plot([i for i in range(week*weekhours, (week+1)*weekhours)], [prediction[i][2] for i in range(week*weekhours, (week+1)*weekhours)], 'red')
        plt.plot([i for i in range(week*weekhours, (week+1)*weekhours)], [real_data[i][2] for i in range(week*weekhours, (week+1)*weekhours)], 'blue')
        b1 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='red')
        b2 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='blue')
        plt.legend([b1,b2], ["prediction water", "real hot water"])
        plt.axis([week*weekhours, (week+1)*weekhours, 0, 1])
        plt.show()
        
def plot_data_single():
    plot_temperature()
    plot_humidity()
    plot_radiation()
    plot_wind_velocity()
    
    plot_energy()
    plot_cold_water()
    plot_hot_water()
    
def plot_error_history(errorHistory):
    plt.plot(errorHistory)
    plt.title("history of absolute error")
    plt.xlabel("episodes")
    plt.ylabel("prediction error")
    plt.show()
    print("minimum error with respect to validation data: %s" % min(errorHistory))