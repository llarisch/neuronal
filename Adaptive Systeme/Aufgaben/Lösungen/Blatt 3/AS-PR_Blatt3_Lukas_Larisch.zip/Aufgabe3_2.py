import matplotlib.patches as mpatches
import matplotlib.pyplot as plt
from PCA import SangerNetwork

#use python27

''' Example 1 '''
S = [[84, 138, 132, 101],
     [109, 157, 141, 135],
     [140, 161, 147, 128],
     [166, 165, 167, 128],
     [205, 197, 197, 181],
     [247, 223, 239, 219]]


''' PCA-ICA-Example '''
T = [[1, 2],
     [2, 4],
     [3, 6]
     ]

''' card1.dt '''
CARD1 = list()


''' reads data from card1.dt into CARD1 '''
def read_data():
    global CARD1
    fin = open('card1.dt', 'r')
    lines = list()
    for line in fin:
        lines.append(line.split(' '))
    
    fin.close()

    for i in range(0, len(lines)):
        V = list()
        for j in range(0, len(lines[0])):
            V.append(float(lines[i][j].replace('\n', '')))
        CARD1.append(V)
        


if __name__ == '__main__':
    #reading card1.dt
    read_data()
    LEARN_RATE = 0.1
    X = CARD1
    eVals, eVecs, dim = SangerNetwork(X, LEARN_RATE)

    #write results to Ergebnisse_card1.txt
    fout = open("Ergebnisse_card1.txt", "w")
    if fout:
        fout.write("###############################################################\n")
        fout.write("Eigenvectors & Eigenvalues\n")
        for i in range(0, len(eVecs)):
            fout.write("--------------------------------------\n")
            fout.write(str(eVecs[i]) + "\n")
            fout.write(str(eVals[i]) + "\n")
        
        fout.write("dimension of data: " + str(dim) + "\n")
    fout.close()
    

    #plot Eigenvalues
    G_x = [x for x in range(1, len(eVals)+1)]
    G_y = eVals
    plt.plot(G_x, G_y)
    plt.axis([1, len(eVals)+1, 0, max(eVals)+1])
    plt.xlabel("attributes")
    plt.ylabel("eigenvalues")
    plt.show()
    