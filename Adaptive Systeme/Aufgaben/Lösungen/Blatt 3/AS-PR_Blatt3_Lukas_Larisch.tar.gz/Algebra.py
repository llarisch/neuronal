import copy
from math import sqrt
import numpy


''' checks if family of vectors is pairwise quasi-orthogonal '''    
def isOrthogonal(EVs, error):
    for i in range(0, len(EVs)):
        for j in range(i+1, len(EVs)):
            scalar_value = 0.0
            for k in range(0, len(EVs[0])):
                scalar_value += EVs[i][k]*EVs[j][k]
            if abs(scalar_value) > error:
                print(str(abs(scalar_value)))
    return True

''' @param:  matrix M
    @return: average vector of M        '''
def MatrixAverage(M):
    A = M[0]
    for i in range(1, len(M)):
        A = numpy.add(A, M[i])
    return (1.0/len(M))*A

''' @param:  matrix M, average vector avg_V
    @return: cencentrate vectors due to average vector '''
def MatrixCentrate(M, avg_V):
    for k in range(0, len(M)):
        M[k] = numpy.subtract(M[k], avg_V)

def VectorNormalize(X):
    X = numpy.dot(1.0/sqrt(numpy.dot(X, X)), X)
    return X


def AutoCorMatrix(X):
    C_xx = numpy.outer(X[0], X[0])
    for i in range(1, len(X)):
        C_xx = numpy.add(C_xx, numpy.outer(X[i], X[i]))
    return (1.0/len(X)) * C_xx


def Eigenvalue(w_i, C_xx_w):
    return (C_xx_w[0] / w_i[0])