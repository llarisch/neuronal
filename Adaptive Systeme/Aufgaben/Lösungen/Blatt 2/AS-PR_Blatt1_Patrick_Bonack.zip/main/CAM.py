# -*- coding: utf-8 -*-
'''
Created on 01.11.2014

@author: patrick
'''

import numpy as np
from copy import copy
class CAM(object):

    '''
    CAM is short for content adressable memory
    
    This is an implementation of a content adressable memory.
    
    It is able to store tuple of shape(key,value) and provides a lookup.
    The basic store function is add(). For Lookup use get() or get_from_Value().
      
    The CAM is also able to store sequences of tuple of the same length
    and can restore missing elements of those sequences.
    Use long_add for adding a sequence of tuple.
    Use long_missing to restore a corrupt sequence
    
    There are to methods do initiate a CAM instance.
    You can create an empty CAM by giving  key and value size.
    On the other hand you can initiate with a given weight matrix.
    This way there will be prestored tuple.
    '''
    

    def __init__(self, len_key, len_value, matrix=[]):
        '''
        Constructor
        
        Parameter:
        len_key,len_value: int
            length of values,length of keys
            
        matrix: array like of array like of int
            this matrix will be the weight matrix
        
        Fields:
        weight : numpy.ndarray := the weight matrix 
        lenv : int := length of values
        lenk : int := length of keys
        
        ''' 
        self.lenk = len_key
        self.lenv = len_value
        if matrix == []:
            self.weight = np.zeros((len_key, len_value), dtype=np.int)
        else:
            matrix = np.array(matrix)
            self.weight = np.ndarray(shape=(len_key, len_value),
                                      buffer=matrix, dtype=np.int)
        
    def __str__(self):
        """
        returns String representation. Its the weight matrix
        """
        return str(self.weight)
    
    def add(self, key, value):
        """ 
        Adds the pair (key,value) to this CAM by recalculating the weight matrix.
           
           matrix_new = matrix_old + key ⊗ value
        
        Parameters:
        key,value: array like
        
        Returns:
        True if pair is added successfully, otherwise returns False
        """
        if len(key) != self.lenk :
            return False        
        if len(value) != self.lenv :
            return False
        self.weight = self.weight + np.outer(key, value)
        return True
    
    def sub(self, key):
        
        """ 
        Removes the pair (key,value) from this CAM by recalculating the weight matrix.
        value is calculated.   
        
        matrix_new = matrix_old - key ⊗ value
        
        Parameters:
        key: array like
        
        Returns:
        True if pair is removed, otherwise returns False
        """
        if len(key) != self.lenk :
            return False        
        value = self.get(key)
        if len(value) != self.lenv :
            return False    
        self.weight = self.weight - np.outer(key, value)
        return True
        
    def get(self, key):
        """
        Calculates the corresponding value to key
         
        value =  transpose(weight) * key
        
        Parameters:
        key: array like 
        
        Returns:you
        numpy.ndarray if calculated successfully, otherwise returns False
        """
        if len(key) != self.lenk :
            return False    
        return self.neuron_out(np.inner(np.transpose(self.weight), key))
    
    def get_from_Value(self, value):
        """
        Calculates the corresponding key to value
         
        value =  weight * key
        
        Parameters:
        value: array like 
        
        Returns:
        key if calculated successfully, otherwise returns False
        """
        if len(value) != self.lenv :
            return False  
        return self.neuron_out(np.inner(self.weight, value))
    
    
    def missing(self, key=0, value=0):
        """
        Calculates the corresponding key to value or value to key
         
    
        Parameters:
        key, value: array like 
        
        Returns:
        key or value if calculated successfully, otherwise returns False
        """
        
        if (key == 0 and value == 0):
            return False
        if (key != 0 and value != 0):
            return False
        if key != 0:
            if len(key) != self.lenk :
                return False  
            return self.get(key)
        else:
            if len(value) != self.lenv :
                return False  
            return self.get_from_Value(value)
    
    def long_add(self,array):
        """
        Adds array to this CAM by recalculating the weight matrix.
        It adds every pair (array[i], array[(i+1)%len(array)]).    
    
        Parameters:
        array: array like of array like
        
        Returns:
        True if array added successfully, otherwise returns False
        """
        if len(array) < 2:
            return False  
        else:
            for i in range(len(array)-1):
                if len(array[i]) != self.lenk:
                    return False 
                self.add(array[i],array[i+1])
            self.add(array[len(array)-1],array[0])
        return True
    
    def long_missing(self,array):
        """ 
        Search for missing Elements of array.
        
        Given array = [False,[1,1,1],False].
        A possible output could be:  [[1,-1,1],[1,1,1],[-1,1,1]]
        
        Parameters:
        array: array like of array like, missing Parameters are encoded as False.
              
        Returns:
        numpy.ndarray with every element if lookup successful.
        Otherwise returns False. 
        
        """

        length = len(array)
        nparray = np.zeros((length,self.lenk), dtype=np.int)
        
        #Find a readable element
        found = -1
        for i in range(length):
            if array[i] != 0:
                found = i
                break
        if found == -1:
            return False
        
        nparray[found] = np.array(array[found])
        
        #repair array for index i: 0 <= i < found        
        for i in range(found-1,-1,-1):  
            if array[i] != 0:
                nparray[i] = np.array(array[i])
            else:
                nparray[i] = self.get_from_Value(nparray[i+1])
        
        #repair array for index i: found < i < len(array)
        for i in range(found+1,length):  
            if array[i] != 0:
                nparray[i] = np.array(array[i])
            else:
                nparray[i] = self.get(nparray[(i-1+length)%length])
        
        return nparray
            
            
            
        
     
    @staticmethod
    def neuron_out(array):
        """ 
        calculates the output of the neuron.
        array_new[i] = 1; array_old[i] >= 0
        array_new[i] = -1; array_old[i] < 0
        
        Given array = [ 1, 7, -8, 0].
        The output is: [ 1, 1, -1, 1]
        
        
        Parameters:
        array: array like of Integer
        
        Returns: numpy.array of numpy.int
        """
        m = np.array(copy(array), dtype=np.int)
        for i in range(len(m)):
            if  m[i] >= 0:
                m[i] = 1
            else:
                m[i] = -1
        return m

       
            
            