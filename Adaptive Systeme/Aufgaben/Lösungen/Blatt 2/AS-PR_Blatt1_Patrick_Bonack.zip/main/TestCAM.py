'''
Created on 01.11.2014

@author: patrick
'''
import unittest
import CAM
import numpy as np
import vectors

class TestCAM(unittest.TestCase):
    
    def testInit(self):
        mycam = CAM.CAM(3,3)
        exp = np.ndarray((3,3),buffer=np.array([[0,0,0],[0,0,0],[0,0,0]]))
        self.assertTrue(np.array_equal(exp, mycam.weight))
        
        mycam = CAM.CAM(1,1)
        exp = np.ndarray((1,1),buffer=np.array([[0]]))
        self.assertTrue(np.array_equal(exp, mycam.weight))
        
        mycam = CAM.CAM(1,3)
        exp = np.ndarray((1,3),buffer=np.array([[0,0,0]]))
        self.assertTrue(np.array_equal(exp, mycam.weight))
        
        mycam = CAM.CAM(3,1)
        exp = np.ndarray((3,1),buffer=np.array([[0],[0],[0]]))
        self.assertTrue(np.array_equal(exp, mycam.weight))


    def testAdd(self):
        mycam = CAM.CAM(3,3)
        mycam.add([1,-1,1],[1,1,1])
        mat = [[1,1,1],[-1,-1,-1],[1,1,1]]
        self.assertTrue(np.array_equal(mat,mycam.weight))
        
        mycam.add([-1,-1,1],[-1,-1,-1])
        mat = [[2,2,2],[0,0,0],[0,0,0]]
        self.assertTrue(np.array_equal(mat,mycam.weight))
        
        mycam.add([-1,-1,1],[-1,-1,-1])
        mat = [[3,3,3],[1,1,1],[-1,-1,-1]]
        self.assertTrue(np.array_equal(mat,mycam.weight))
        
        mycam.add([1,1,1],[1,1,-1])   
        mat = [[4,4,2],[2,2,0],[0,0,-2]]
        self.assertTrue(np.array_equal(mat,mycam.weight))
        
    def testSub(self):
        mycam = CAM.CAM(3,3)
        mycam.add([1,-1,1],[1,1,1])    
        mycam.add([-1,-1,1],[-1,-1,-1])    
        mycam.add([1,1,1],[1,1,-1])  
        self.assertTrue(np.array_equal(mycam.get([1,1,1]),[1,1,-1])) 
        mycam.sub([1,-1,1])      
        self.assertFalse(np.array_equal(mycam.get([1,-1,1]),[1,1,1]))
        self.assertTrue(np.array_equal(mycam.get([-1,-1,1]),[-1,-1,-1])) 
        self.assertTrue(np.array_equal(mycam.get([1,1,1]),[1,1,-1])) 
           
    def testS(self):
        self.assertTrue([1,1],CAM.CAM.neuron_out([3,3]))
        self.assertTrue([1,1],CAM.CAM.neuron_out([0,0]))
        self.assertTrue([-1,1],CAM.CAM.neuron_out([-5,3]))
        self.assertTrue([1,-1],CAM.CAM.neuron_out([3,-42]))
        
    def testGet(self):
        mycam = CAM.CAM(7,8)
        for i in range(1,5):
            mycam.add(vectors.a[i],vectors.b[i])
        for i in range(1,5):
            b = mycam.get(vectors.a[i])
            self.assertTrue(np.array_equal(vectors.b[i],b))
            
        mycam2 = CAM.CAM(8,7)
        for i in range(1,5):
            mycam2.add(vectors.b[i],vectors.a[i])
        for i in range(1,5):
            a = mycam2.get(vectors.b[i])
            self.assertTrue(np.array_equal(vectors.a[i],a))
            
    def testGet_from_Value(self):
        mycam = CAM.CAM(7,8)
        for i in range(1,5):
            mycam.add(vectors.a[i],vectors.b[i])
        for i in range(1,5):
            a = mycam.get_from_Value(vectors.b[i])
            self.assertTrue(np.array_equal(vectors.a[i],a))
        mycam2 = CAM.CAM(8,7)
        for i in range(1,5):
            mycam2.add(vectors.b[i],vectors.a[i])
        for i in range(1,5):
            b = mycam2.get_from_Value(vectors.a[i])
            self.assertTrue(np.array_equal(vectors.b[i],b))
            
    def testMissing(self):
        mycam = CAM.CAM(7,8)
        for i in range(1,5):
            mycam.add(vectors.a[i],vectors.b[i])
        for i in range(1,5):
            b = mycam.missing(key=vectors.a[i])
            a = mycam.missing(value=vectors.b[i])
            self.assertTrue(np.array_equal(vectors.b[i],b))
            self.assertTrue(np.array_equal(vectors.a[i],a))
            
        mycam2 = CAM.CAM(8,7)
        for i in range(1,5):
            mycam2.add(vectors.b[i],vectors.a[i])
        for i in range(1,5):
            a = mycam2.missing(key=vectors.b[i])
            b = mycam2.missing(value=vectors.a[i])
            self.assertTrue(np.array_equal(vectors.b[i],b))
            self.assertTrue(np.array_equal(vectors.a[i],a))
    
    def testLong_add(self):
        mycam = CAM.CAM(7,7)
        mycam.long_add(vectors.a[1:9])
        a = vectors.a[1:9]
        for i in range(7):
            n = mycam.missing(key=a[i])
            b = mycam.missing(value=a[i])
            next_exp = a[(i+1)%8]
            before_exp = a[(i-1+8)%8]
            self.assertTrue(np.array_equal(n, next_exp))
            self.assertTrue(np.array_equal(b, before_exp))
    
    def testLong_Missing(self):
        v = vectors
        mycam = CAM.CAM(7,7)
        mycam.long_add(v.a[1:9])
        mis_array = [False,v.a[2],False,v.a[4],False,v.a[6],v.a[7],False]
        found_array = mycam.long_missing(mis_array)
        self.assertTrue(np.array_equal(found_array, v.a[1:9]))
    
    def testLong_Missing_no_Elements(self):
        v = vectors
        mycam = CAM.CAM(7,7)
        mycam.long_add(v.a[1:9])
        mis_array = [False,False,False,False,False,False,False,False]
        found_array = mycam.long_missing(mis_array)
        self.assertTrue(found_array ==  False)
        
        
    def testLong_Missing_by_Matrix(self):
        v = vectors
        matrix = np.array(v.matrix)
        mycam = CAM.CAM(7,7,matrix)
        
        mis_array1 = [0,v.a[3],0]
        full_array1 = [v.a[1],v.a[3],v.a[2]]
        
        mis_array2 = [0,v.a[7],0,0,v.a[4]]
        full_array2 = [v.a[8],v.a[7],v.a[6],v.a[5],v.a[4]]

        self.assertTrue(np.array_equal(mycam.long_missing(mis_array1), full_array1))
        self.assertTrue(np.array_equal(mycam.long_missing(mis_array2), full_array2))
    
    
    def testBig(self):   
        v = vectors
        mycam = CAM.CAM(7,7)
        seq1 = v.a[1::2]
        seq2 = v.a[2::2]
        mycam.long_add(seq1)
        mycam.long_add(v.a[2::2])
        miss1 = 4*[0]
        miss1[3] = v.a[7]
        miss2 = [0,v.a[4],v.a[6],0]
        self.assertTrue(np.array_equal(mycam.long_missing(miss1), seq1))
        self.assertTrue(np.array_equal(mycam.long_missing(miss2), seq2))
        
if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()