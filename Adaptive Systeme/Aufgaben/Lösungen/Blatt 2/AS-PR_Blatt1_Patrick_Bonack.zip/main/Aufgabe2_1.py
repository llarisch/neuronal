# -*- coding: utf-8 -*-
'''
Created on 01.11.2014

@author: patrick bonack
'''
import numpy as np
import CAM
import vectors
v = vectors


if __name__ == '__main__':
    """ Die Main Funktion dient dazu, die Lösung der Aufgaben anschaulich
     zu beantworten.
     Führen sie dazu dieses Skript aus.
     """

    print "Zur Lösung der Aufgabe benutze ich Python 2.7.6"
    print "Geschrieben und getestet wurde das Programm auf Ubuntu 14.04.1 LTS"
    print "Zusätzlich sollte darauf geachtet werden, dass utf-8 ordnungsgemäß angezeigt werden kann"
    print ""
    print "Teilaufgabe a)"
    print "Die Implemenation des Speichers ist die Klasse CAM"
    print "Ich Initialisiere nun einen CAM mycam der Tupel der Form (ai,bi) speichern kann"
    mycam = CAM.CAM(7,8)
    print ""
    print "Nun füge ich die entsprechenden Tupel in den CAM ein"
    for i in range(1,5):
        mycam.add(vectors.a[i],vectors.b[i])
    print ""
    print "Nun überprüfe ich die Eingaben:"    
    for i in range(1,5):
        print "(",vectors.a[i],",",mycam.get(vectors.a[i]),")"
    print "Wie man sehen kann entspricht das der Erwartung."
    print ""
    print "Die zugehörige Speichermatrix lautet:"
    print mycam.weight
    print ""
    print "Nun überprüfe ich was passiert, wenn ich an einer Stelle veränderte Eingabevektoren nutze"
    for i in range(1,5):
        print "(",vectors.a_one_diff[i],",",mycam.get(vectors.a_one_diff[i]),")"
    print "Die Ausgaben unterscheiden sich nicht von den Ausgaben der Originalvektoren"
    print ""
    print "Teilaufgabe b)"
    print "Ich erstelle nun einen CAM mycam2 für die Tupel der Form (bi,ai)"
    mycam2 = CAM.CAM(8,7)
    for i in range(1,5):
        mycam2.add(vectors.b[i],vectors.a[i])
    print "Die zugehörige Matrix lautet:"
    print mycam2.weight
    print "Zur Erinnerung die alte Matrix sah folgendermaßen aus:"
    print mycam.weight
    print "Wie man leicht sehen kann, sind die Matrizen transponiert zueinander"
    print "Betrachtet man die Funktion zum Einfügen in den CAM, so sieht man,"
    print "dass durch Austauschen der beidem Eingabenvektoren eine Matrix erzeugt wird,"
    print "die der transponierten Gewichtsmatrix entspricht"
    print "Die Information kann man dazu nutzen, aus einem Value den zugehörigen Key zu berechen"
    print "Die Funktion missing rekonstruiert das fehlende tupel-Element"
    print "b fehlt:"
    for i in range(1,5):
        print "(",vectors.a[i],",",mycam.missing(key=vectors.a[i]),")"
    print "a fehlt"
    for i in range(1,5):
        print "(",mycam.missing(value=vectors.b[i]),",",vectors.b[i],")"
    print "Wie man sehen kann wurden die fehlenden Elemente erfolgreich rekonstruiert"
    print ""
    print "Teilaufgabe c"
    print "Zunächst muss brauchen wir einen CAM mit der entsprechenden Matrix"
    mycam3 = CAM.CAM(7,7,vectors.matrix)
    print "Die geladene Matrix sieht folgendermaßen aus:"
    print mycam3.weight
    
    print "Nun füllen wir folgendes Tupel:"
    print vectors.miss_array1
    print "Gefüllt sieht es so aus"
    print mycam3.long_missing(vectors.miss_array1)
    print "Die fehlenden Werte entsprechen also a1 und a2"
    print ""
    print "Nun wird das zweite Tupel gefüllt"
    print vectors.miss_array2
    print "Dies sieht gefüllt folgendemaßen aus:"
    print mycam3.long_missing(vectors.miss_array2)
    print "Das Tupel entspricht also (a8,a7,a6,a5,a4)"
    print ""

