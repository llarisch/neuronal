from Hebb_Assoc import *

#using python27

A=  [[ 1, 1, 1, 1, 1, 1, 1],
     [-1, 1,-1, 1,-1, 1,-1],
     [-1,-1, 1, 1,-1,-1, 1],
     [ 1,-1,-1, 1, 1,-1,-1],
     [-1,-1,-1,-1, 1, 1, 1],
     [ 1,-1, 1,-1,-1, 1,-1],
     [ 1, 1,-1,-1,-1,-1, 1],
     []
     ]

A_= [[ 1, 1,-1, 1, 1, 1, 1],#3
     [-1, 1,-1, 1, 1, 1,-1],#5
     [-1, 1, 1, 1,-1,-1, 1],#2
     [ 1,-1,-1, 1, 1,-1, 1],#7
     [-1,-1,-1,-1, 1,-1, 1],#6
     [ 1, 1, 1,-1,-1, 1,-1],#2
     [ 1, 1,-1,-1,-1,-1,-1],#7
     []
     ]

B = [[ 1,-1,-1,-1,-1,-1,-1, 1],
     [-1, 1,-1,-1,-1,-1, 1,-1],
     [-1,-1, 1,-1,-1, 1,-1,-1],
     [-1,-1,-1, 1, 1,-1,-1,-1]
     ]

W = [[-3,-3, 5,-3, 1, 1, 1],
     [ 3,-1, 3,-1,-5,-1, 3],
     [-5,-1,-5,-1,-5,-1, 3],
     [-3, 5, 5, 5, 1, 1, 1],
     [ 1, 1, 1, 1, 1,-7, 1],
     [-1,-5,-1, 3, 3,-1, 3],
     [-1,-5,-1, 3,-5,-1,-5]]

'''
usage
H = Hebb_Assoc()
H.insert(A[i], B[i])
H.remove(A[i], B[i])
H.read(A[i])
H.get_matrix_of_weights()
'''

''' tests whether pattern can be recognized after insertion: yes '''
def Aufg1_a1():
    H = Hebb_Assoc()
    for i in range(0, 4):
        H.insert(A[i], B[i])
        output = H.read(A[i])
        print("output: " + str(output))
        print("pattern matched = " + str(output == B[i][:7]))
        print(str(H.read(A[i])))
        print(str(B[i]))
        print("---------------------------------------------")

''' tests whether pattern with single error can be 
    recognized after insertion, 3th one: no '''
def Aufg1_a2():
    H = Hebb_Assoc()
    for i in range(0, 4):
        H.insert(A_[i], B[i])
        print("output: " + str(H.read(A_[i])))
        print("pattern matched = " + str(H.read(A[i]) == B[i][:7]))
        print("---------------------------------------------")

''' tests whether matching is symmetic: yes '''       
def Aufg1_b():
    H = Hebb_Assoc()
    for i in range(0, 4):
        H.insert(B[i], A[i])
        print("output: " + str(H.read(B[i])))
        print("pattern matched = " + str(H.read(B[i])[:7] == A[i][:7]))
        print("---------------------------------------------")

''' example of inserting tuple of >= 3 entries 
        [inserting A[i], A[i+1]; i++, i < n] '''
def Aufg1_c1():
    H = Hebb_Assoc()
    H.insert(A[0], A[1])
    H.insert(A[1], A[2])
    H.insert(A[2], A[3])
    H.insert(A[3], A[0])
    M = A[0]
    for i in range(0, 4):
        M = H.read(M)
        print("output: " + str(M))

''' example of reconstruting an 3-length tuple 
    ( - , a_3 , - ) -> ( a_2 , a_3 , a_1 ) '''
def Aufg1_c2_1():
    H = Hebb_Assoc()
    H.set_matrix_of_weights(W)
    
    #start with a_3
    M = A[2]
    
    for i in range(0, 3):
        M = H.read(M)
        print("output: " + str(M))
        if M in A:
            print("that's A["+ str(A.index(M)) + "] <-> a_" + str(A.index(M)+1))
        else:
            print("could not reconstruct pattern")
    print("output: " + str(H.read(A[2])))

''' example of reconstruting an 5-length tuple 
    ( - , a_7 , - , - , a_4 ) -> ( - , a_7 , a_6 , a_5 , a_4 ) '''
def Aufg1_c2_2(): 
    G = Hebb_Assoc()
    G.set_matrix_of_weights(W)
    
    #start with a_7
    M = A[6]
    
    for i in range(0, 5):
        M = G.read(M)
        print("output: " + str(M))
        if M in A:
            print("that's A["+ str(A.index(M)) + "] <-> a_" + str(A.index(M)+1))
        else:
            print("could not reconstruct pattern")
            
    
if __name__ == "__main__":
    ''' do not uncomment more than one function 
            [due to effects on python's object references] '''
    Aufg1_a1()
    #Aufg1_a2()
    #Aufg1_b()
    #Aufg1_c1()
    #Aufg1_c2_1()
    #Aufg1_c2_2()