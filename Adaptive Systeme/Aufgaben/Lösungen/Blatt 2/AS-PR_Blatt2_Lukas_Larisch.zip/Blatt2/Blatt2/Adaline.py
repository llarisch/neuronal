import copy
import random

''' given a matrix and an index, returns a the corresponding column vector '''
def ColumnVector(W, idx):
    tmp = list()
    for i in range(0, len(W)):
        if idx >= len(W[i]):
            print("[Vector.ColumnVector]: idx out of range")
            return []
        tmp.append(W[i][idx])
    return tmp

''' returns the scalar product of two vectors given as lists of floats '''
def Scalar(X, Y):
    rtn = 0.0
    for i in range(0, max(len(X), len(Y))):
        rtn += X[i]*Y[i]
    return rtn

''' an adaline '''
class Adaline(object):
    def __init__(self, max_n, max_m, S, learn_rate=0.1):
        self.__W = list()
        #init W with zeros
        for i in range(0, max_m):
            self.__W.append(list())
            for j in range(0, max_n):
                self.__W[i].append(0.0)
                
        self.__learn_rate = learn_rate
        self.__max_X = max_n
        self.__max_L = max_m
        self.__S = S
        
        self.__W_copy = list()
    
    ''' zeros some entries in W in dependency of pby '''
    def zero_weight_vector(self, pby):
        for i in range(0, len(self.__W)):
            for j in range(0, len(self.__W[i])):
                rnd = random.randint(0, 1000)
                if rnd < pby*10:
                    self.__W[i][j] = 0.0
            
    def save_weight_matrix(self):
        self.__W_copy = copy.deepcopy(self.__W)

    def restore_weight_matrix(self):
        self.__W = copy.deepcopy(self.__W_copy)
    
    ''' -calculates neural network activity 
        -learns from input X and L, given as lists of floats
        -returns False if an error occured, else True '''
    def work(self, X, L):
        #read input
        if len(X) > self.__max_X:
            print("error: X too large!")
            return False
        if len(L) > self.__max_L:
            print("error: L too large!")
            return False
        x2 = Scalar(X, X)
        
        #activity
        z = list()
        y = list()
        for i in range(0, self.__max_L):
            z.append(Scalar(ColumnVector(self.__W, i), X))
            y.append(self.__S(z[i]))
        
        #learning
        for i in range(0, self.__max_L):
            for j in range(0, self.__max_X):
                self.__W[i][j] -= self.__learn_rate*(z[i]-L[i])*X[j]/x2
        
        return True
    
    ''' calculates and returns network output with respect to X, given 
        as a list of floats 
        returns a list of floats '''
    def read(self, X):
        output = list()
        for i in range(0, len(self.__W)):
            z = 0.0
            z += Scalar(X, self.__W[i])
            z = 1.0 if z >= 0 else -1.0
            output.append(z)   
        return output
