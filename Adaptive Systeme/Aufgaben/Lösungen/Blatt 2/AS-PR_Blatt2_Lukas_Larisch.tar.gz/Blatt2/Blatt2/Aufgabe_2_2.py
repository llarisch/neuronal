from Digits import *
import Adaline
import random
import copy
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

#use python27

''' prints one digit given as a list of values in {-1, 1} '''
def print_digit(digit):
    string = ""
    for i in range(0, len(digit)):
        if digit[i] == 1:
            string += "x"
        else:
            string += " "
        if i%8 == 0 or i == len(digit)-1:
            print(string)
            string = ""

''' invertes some values of an input given as a list in dependency
    of the float possibility '''
def make_noisy(X, possiblilty):
    noisy = list()
    for i in range(0, len(X)):
        rnd = random.randint(0, 1.0/possiblilty)
        if rnd == 1:
            noisy.append(1 if X[i] == -1 else -1)
        else:
            noisy.append(X[i])
    return noisy

''' evaluates the hamming distance of two vectors specifies as lists of floats '''
def pixel_error_count(X, Y):
    cnt = 0
    for i in range(0, min(len(X), len(Y))):
        if X[i] != Y[i]:
            cnt += 1
    return cnt
        
''' runtime ~20secs '''
def Aufg_2a():
    A = Adaline.Adaline(80, 80, lambda x: 1 if x >= 0 else -1, 0.01)
    
    ''' regular input '''
    for counter in range(0, 100):
        for i in range(0, 10):
            A.work(Digits[i], Digits[i])

    ''' noisy input '''
    for counter in range(0, 3):
        for i in range(0, 10):
            rnd = random.randint(0, 79)
            pby = random.randint(0, 100)
            if pby <= 10:
                Error_X = copy.copy(Digits[i])
                Error_X[rnd] = -1 if Digits[i][rnd] == 1 else 1
                A.work(make_noisy(Digits[i], 0.1), Digits[i])
            else:
                A.work(Digits[i], Digits[i])
            

    regular_digit = list()
    noisy_digit = list()
    output_digit = list()
    
    for i in range(0, 10):
        regular_digit.append(Digits[i])
        noisy_digit.append(make_noisy(Digits[i], 0.1))
        output_digit.append(A.read(noisy_digit[-1]))

    for i in range(0, 10):
        print_digit(regular_digit[i])
        print_digit(noisy_digit[i])
        print_digit(output_digit[i])

''' runtime ~30secs '''
def Aufg_2b():
    A = Adaline.Adaline(80, 80, lambda x: 1 if x >= 0 else -1, 0.01)
    
    ''' regular input '''
    for counter in range(0, 100):
        for i in range(0, 10):
            A.work(Digits[i], Digits[i])
    
    ''' noisy input '''
    for counter in range(0, 50):
        for i in range(0, 10):
            rnd = random.randint(0, 79)
            pby = random.randint(0, 100)
            if pby <= 10:
                Error_X = copy.copy(Digits[i])
                Error_X[rnd] = -1 if Digits[i][rnd] == 1 else 1
                A.work(make_noisy(Digits[i], 0.1), Digits[i])
            else:
                A.work(Digits[i], Digits[i])
    
    x_vector = list()
    y_vector = list()
    A.save_weight_matrix()
    #for all possibility-values i 
    for i in range(0, 51):
        error_sum = 0
        x_vector.append(i)
        #for all patterns
        for k in range(0, 10):
            A.zero_weight_vector(i)
            #10 times due to a little "avarage" 
            for j in range(0, 10):
                noisy = A.read(Digits[j])
                errors = pixel_error_count(Digits[j], noisy)
                error_sum += errors
            A.restore_weight_matrix()
        error_sum = float(error_sum)/10.0
        y_vector.append(error_sum)
    
    #plotting stuff
    x_value = 0
    y_value = 0
    for i in range(0, len(y_vector)):
        if y_vector[i] <= 1.0:
            x_value = i
            y_value = y_vector[i]
    #thats the rightmost point <= 1.0
    plt.plot(x_vector, y_vector, 'ro')
    #thats f(x) = 1
    plt.plot([x for x in range(0, 50)], [1 for i in range(0, 50)])
    plt.plot([x_value], [y_value], 'g^')
    plt.axis([0, 50, 0, 10])
    plt.xlabel("~p% erased entries")
    plt.ylabel("estimated errors")
    b1 = plt.bar([0, -1, -2], [0.2, 0.3, 0.1], width=0.2, align="center", color='green')
    b2 = plt.bar([0, -1, -2], [0.2, 0.3, 0.1], width=0.2, align="center", color='red')
    plt.legend([b1, b2], ["average error", "rightmost value <= 1"])
    plt.show()
        
if __name__ == '__main__':
    ''' - do not uncomment more than one function 
            [due to possible effects of python's object references] 
        - running time ~30 secs each '''
    Aufg_2a()
    #Aufg_2b()