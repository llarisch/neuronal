
class Hebb_Assoc(object):
    def __init__(self):
        self.__Weights_Matrix = list()
        self.__Pattern_Tuple = list()
        

    ''' inserting pattern X with teacher's vector L,
        both given as lists of floats '''    
    def insert(self, X, L):
        if len(X) >= len(L):
            for i in range(0, len(X)-len(L)):
                L.append(0.0)
        self.__Pattern_Tuple.append([X, L])
        
        #dyadic product of X and L
        dyadic_product = list()
        for i in range(0, len(X)):
            dyadic_product.append(list())
            for j in range(0, len(L)):
                dyadic_product[i].append(X[i]*L[j])
         
        #update matrix of weights
        for i in range(0, len(dyadic_product)):
            if len(self.__Weights_Matrix) < i+1:
                self.__Weights_Matrix.append(list())
            for j in range(0, len(dyadic_product[i])):
                if len(self.__Weights_Matrix[i]) < j+1:
                    self.__Weights_Matrix[i].append(0.0)
                self.__Weights_Matrix[i][j] += dyadic_product[i][j]

        self.print_matrix_of_weights()
        print("pattern inserted")
        return True
    
    ''' removing pattern X, associated with L, by 
        simply reverse the operation of inserting
        --- does not restore matrix of weights '''
    def remove(self, X, L):
        if [X, L] not in self.__Pattern_Tuple:
            print("pattern not associated!")
            return False
        else:
            idx = self.__Pattern_Tuple.index([X,L])
            self.__Pattern_Tuple.pop(idx)
            
            #dyadic product of X and L
            dyadic_product = list()
            for i in range(0, len(X)):
                dyadic_product.append(list())
                for j in range(0, len(L)):
                    dyadic_product[i].append(X[i]*L[j])
                    
            #update matrix of weights
            for i in range(0, len(dyadic_product)):
                if len(self.__Weights_Matrix) < i+1:
                    self.__Weights_Matrix.append(list())
                for j in range(0, len(dyadic_product[i])):
                    if len(self.__Weights_Matrix[i]) < j+1:
                        self.__Weights_Matrix[i].append(0.0)
                    self.__Weights_Matrix[i][j] -= dyadic_product[i][j]
                    
            print("pattern deleted")
            return True
            
    ''' calculating and returning neuronal network output '''
    def read(self, X):
        output = list()
        z = float()
        
        #fitting size of matrix of weights to X
        while len(self.__Weights_Matrix) < len(X):
            self.__Weights_Matrix.append(list())
        
        for i in range(0, len(self.__Weights_Matrix)):
            while len(self.__Weights_Matrix[i]) < len(X):
                self.__Weights_Matrix[i].append(0)
        
        #calculate output of network        
        for i in range(0, len(self.__Weights_Matrix)):
            z = 0.0
            for j in range(0, len(X)):
                z += X[j]*self.__Weights_Matrix[j][i]
            #print(str(z))    
            z = 1 if z >= 0 else -1
            output.append(z)   
        return output  
            

    
    ''' helpers '''
    
    def set_matrix_of_weights(self, W):
        self.__Weights_Matrix = W    
    
    def get_matrix_of_weights(self):
        return self.__Weights_Matrix
    
    def print_matrix_of_weights(self):
        print_str = str()
        for i in range(0, len(self.__Weights_Matrix)):
            print_str = "("
            for j in range(0, len(self.__Weights_Matrix[i])):
                print_str += (4-len(str(self.__Weights_Matrix[i][j])))*' ' + str(self.__Weights_Matrix[i][j]) + ','
            print_str = print_str[:-1]
            print_str += ')'
            print(print_str)
        