import math
import Adaline
import matplotlib.pyplot as plt
import MLP

if __name__ == '__main__':
    x_n = lambda x: math.sin(x+math.sin(x**2))
    Adaline_Instance = Adaline.Adaline(20, 1, lambda x: x)
    MLP_Instance = MLP.MLP(20,1, 1)
    
    for iter in range(0, 1):
        for n in range(0, 980):
            X = list()
            for k in range(n, n+20):
                X.append(x_n(k))
            S = x_n(n+21)
            Adaline_Instance.work(X, S)
            MLP_Instance.training(X, [S])
            
    print("matrix of Adaline after training")
    print(str(Adaline_Instance.get_weights_matrix()))
    
    print("matrix of hidden layer after training")
    print(str(MLP_Instance.W1))
    
    print("matrix of output layer after training")
    print(str(MLP_Instance.W2))
    
    output_adaline = list()
    output_mlp = list()
    output_function = list()
    adaline_abs_error = 0.0
    mlp_abs_error = 0.0
    adaline_error = list()
    mlp_error = list()
    
    for n in range(1000, 2001):
        X = list()
        for k in range(n-20, n):
            X.append(x_n(k))
            
        output_adaline.append(Adaline_Instance.read(X)[0])
        output_function.append(x_n(n))
        output_mlp.append(MLP_Instance.output(X)[0])
        adaline_abs_error += abs(output_adaline[n-1000]-output_function[n-1000])
        mlp_abs_error += abs(output_mlp[n-1000]-output_function[n-1000])
        adaline_error.append(output_function[n-1000]-output_adaline[n-1000])
        mlp_error.append(output_function[n-1000]-output_mlp[n-1000])
        
    adaline_abs_error /= 1000.0
    mlp_abs_error /= 1000.0
    
    print("average error adaline: " + str(adaline_abs_error))
    print("")
    print("average error mlp: " + str(mlp_abs_error))    
    
    y = [y for y in range(1000, 1101)]
    plt.plot(y, output_adaline[:101], 'r')
    plt.plot(y, output_mlp[:101], 'b')
    plt.plot(y, output_function[:101], 'g')
    plt.xlabel("x")
    plt.ylabel("sin(x+sin(x^2))")
    plt.axis([999, 1101, -1, 1])

    b1 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='red')
    b2 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='green')
    b3 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='blue')
    plt.legend([b1, b2, b3], ["adaline", "function", "MLP"])
    plt.show()
    
    y = [y for y in range(1000, 2001)]
    plt.plot(y, adaline_error, 'r')
    plt.plot(y, mlp_error, 'b')
    plt.xlabel("x")
    plt.ylabel("error")
    plt.axis([1000, 2000, -2, 2])
    
    b1 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='red')
    b2 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='blue')
    plt.legend([b1, b2], ["error adaline", "error mlp"])
    plt.show()