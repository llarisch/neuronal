import MLP
import matplotlib.pyplot as plt
import random

if __name__ == '__main__':

    X = [[1,0,0,0,0,0,0,0],
         [0,1,0,0,0,0,0,0],
         [0,0,1,0,0,0,0,0],
         [0,0,0,1,0,0,0,0],
         [0,0,0,0,1,0,0,0],
         [0,0,0,0,0,1,0,0],
         [0,0,0,0,0,0,1,0],
         [0,0,0,0,0,0,0,1]
          ]
    #pdf-example
    
    Xexample = [0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8]
    Lexample = [1.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0]

    MLP_Instance = MLP.MLP(8, 3, 8)
    for epoche in range(0, 100):
        rnd = random.randint(0, 7)
        #MLP_Instance.training(Xexample, Lexample)
        MLP_Instance.training(X[rnd], X[rnd])
        
    print("W1")
    print(str(MLP_Instance.W1))
    print("W2")
    print(str(MLP_Instance.W2))
    
    print("quadratic errors: " + str(MLP_Instance.errors_second_layer))
    print("")
    print("output")
    for i in range(0, 3):
        print(str(i+1) + "   " + str(MLP_Instance.output(X[i])))

    """
    MLP_Instance = MLP.MLP(8, 3, 8)
    for epoche in range(0, 1000):
        for pattern in range(0, 8):
            if MLP_Instance.training(X[pattern], X[pattern]):
                break

    print("quadratic errors: " + str(MLP_Instance.errors_second_layer))
        
    x = [i for i in range(0, len(MLP_Instance.errors_second_layer))]
    plt.plot(x, MLP_Instance.errors_second_layer, 'r')
    plt.xlabel("x")
    plt.ylabel("error")
    plt.axis([0, len(MLP_Instance.errors_second_layer), 0, max(MLP_Instance.errors_second_layer)])

    b1 = plt.bar([0, 1, 2], [0.2, 0.3, 0.1], width=0.2, align="center", color='red')
    plt.legend([b1], ["error"])
    plt.show()
    
    print("")
    print("output")
    for i in range(0, 8):
        print(str(MLP_Instance.output(X[i])))
    """