import numpy
import math
import copy
import sys

class MLP(object):
    def __init__(self, n, p, m):
        self.n = n
        self.p = p
        self.m = m
        
        self.W1 = list()
        self.W2 = list()
        self.deltaW1 = list()
        self.deltaW2 = list()
        
        self.X1 = [0.0 for n in range(0, self.n+1)]
        self.X2 = [0.0 for p in range(0, self.p+1)]
        
        self.y2 = list()
        self.d2 = list()
        
        self.bias1 = 0.0
        self.bias2 = 1.0
        
        for i in range(0, self.p):
            self.W1.append(list())
            self.deltaW1.append(list())
            self.W1[i].append(self.bias1)
            self.deltaW1[i].append(0.0)
            for j in range(0, self.n):
                self.W1[i].append(1.0)
                self.deltaW1[i].append(0.0)
        
        for i in range(0, self.m):
            self.W2.append(list())
            self.deltaW2.append(list())
            self.W2[i].append(self.bias2)
            self.deltaW2[i].append(0.0)
            for j in range(0, self.p):
                self.W2[i].append(1.0)
                self.deltaW2[i].append(0.0)
            
            self.y2.append(0.0)
            self.d2.append(0.0)
            
        self.S1 = lambda x: 1.0/(1.0+math.exp(-x))
        self.dS1 = lambda x: (1.0 - self.S1(x))*self.S1(x)
        
        self.S2 = lambda x: x
        self.dS2 = lambda x: 1.0
        
        self.errors_second_layer = list()
        
        self.learn_rate = 1.0
        
    def readPattern(self, X):
        self.X1[0] = 1.0
        for i in range(0, self.n):
            self.X1[i+1] = X[i]
        
    def training(self, X, L):
        for i in range(0, self.m):
            for j in range(0, self.p+1):
                self.deltaW2[i][j] = 0.0
        for i in range(0, self.p):
            for j in range(0, self.n+1):
                self.deltaW1[i][j] = 0.0
        
        self.readPattern(X)
        
        #output hidden layer
        self.Z1 = list()
        self.X2[0] = self.bias2
        for i in range(0, self.p):
            self.Z1.append(numpy.dot(self.W1[i], self.X1))
            self.X2[i+1] = self.S1(self.Z1[i])
        
        #output and error second layer
        self.errors_second_layer.append(0.0)
        
        for i in range(0, self.m):
            self.y2[i] = self.S2(numpy.dot(self.W2[i], self.X2))
            self.d2[i] = -(self.y2[i]-L[i])*self.dS2(self.y2[i])
            
            self.errors_second_layer[-1] += (self.y2[i]-L[i])**2
        self.errors_second_layer[-1] = math.sqrt(self.errors_second_layer[-1])
        
        
        #improve weights second layer
        for i in range(0, self.m):
            for j in range(0, self.p+1):
                self.deltaW2[i][j] += self.learn_rate*self.d2[i]*self.X2[j]
                
        
        def SumProd(i):
            value = 0.0
            for k in range(0, self.m):
                value += self.d2[k] * self.W2[k][i]
            return value

        #improve weights first layer
        for i in range(0, self.p):
            for j in range(0, self.n+1):
                self.deltaW1[i][j] += self.learn_rate*SumProd(i+1)*self.dS1(self.Z1[i])*self.X1[j]
                #print(str(SumProd(i+1)) + " * " + str(self.dS1(self.Z1[i])) + " * " + str(self.X1[j]) + " = " + str(self.deltaW1[i][j]))
        
        for i in range(0, self.p):
            for j in range(0, self.n+1):
                self.W1[i][j] += self.deltaW1[i][j]
                
        for i in range(0, self.m):
            for j in range(0, self.p+1):
                self.W2[i][j] += self.deltaW2[i][j]
    

        print("output hidden layer: " + str(self.X2))
        print("")       
        print("output second layer: " + str(self.y2))
        print("")
        print("error second layer: " + str(self.d2))
        print("")
        print("deltaW1") 
        print(str(self.deltaW1))
        print("")
        print("deltaW2")
        print(str(self.deltaW2))
        print("")
        print("improved W1")
        print(str(self.W1))
        print("")
        print("improved W2")
        print(str(self.W2))


        
    def output(self, X):
        self.readPattern(X)
        
        self.X2[0] = self.bias2
        for i in range(0, self.p):
            self.X2[i+1] = self.S1(numpy.dot(self.W1[i], self.X1))

        for i in range(0, self.m):
            self.y2[i] = self.S2(numpy.dot(self.W2[i], self.X2))
            self.y2[i] = abs(round(self.y2[i]))

        return self.y2
