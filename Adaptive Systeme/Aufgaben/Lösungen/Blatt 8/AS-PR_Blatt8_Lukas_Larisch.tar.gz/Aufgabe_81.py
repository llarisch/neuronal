#use python27

from scipy import ndimage
from scipy import misc
import numpy
import matplotlib.pyplot as plt
import Kohonengas
import random

def show_image(image):
    plt.imshow(image)
    plt.show()

if __name__ == '__main__':
    image = misc.imread("form.png")
    image_arr = numpy.array(image)
    
    iterations = 5000
    plot_time = [100, 500, 1000, 3000, 5000]
        
    KohonengasInstance = Kohonengas.Kohonengas(neurons_count=256, weights_count=2,  \
                                               lambda_init=0.5, lambda_end=0.01, \
                                               learn_rate_init=30.0, learn_rate_end=0.01, \
                                               t_max=iterations, tau=30, max_pattern_range=512,data=image)
    
    
    for i in range(0, iterations):
        found = False
        while(True):
            rnd_x = random.randint(0, len(image)-1)
            rnd_y = random.randint(0, len(image[-1])-1)
            if(image[rnd_x][rnd_y] == 0):
                KohonengasInstance.work([rnd_x, rnd_y])
                break
        if i+1 in plot_time:
            KohonengasInstance.plot_current_configuration()
