import math
import matplotlib.pyplot as plt
import numpy
import random

class Kohonengas():
    def __init__(self, neurons_count, weights_count, \
                       lambda_init, lambda_end, 
                       learn_rate_init, learn_rate_end, 
                       t_max, tau, max_pattern_range, data):
        self.neurons_count = neurons_count
        
        self.learn_rate_init = learn_rate_init
        self.learn_rate_end = learn_rate_end
        self.learn_rate_current = float()
        if not(self.learn_rate_end < self.learn_rate_init or self.learn_rate_init < 1.0):
            print("warning: learn rate configuration")
            
        self.lambda_init = lambda_init
        self.lambda_end = lambda_end
        self.lambda_current = float()
        if not(self.lambda_end < self.lambda_init or self.lambda_init < 1.0):
            print("warning: lambda configuration")
        
        self.t_max = t_max
        self.t_current = 0
        
        self.tau = tau
        
        self.W = list()
        for i in range(0, self.neurons_count):
            while(True):
                rnd_x = random.randint(0, len(data)-1)
                rnd_y = random.randint(0, len(data[-1])-1)
                if(data[rnd_x][rnd_y] == 0):
                    self.W.append(numpy.array([float(rnd_x), float(rnd_y)]))
                    break
                #self.W.append(numpy.array([float(random.randint(0, max_pattern_range-1)) for j in range(0, weights_count)]))
            
        self.A = list()
        for i in range(0, self.neurons_count):
            self.A.append([0 for j in range(0, neurons_count)])
            
        self.T = list()
        for i in range(0, self.neurons_count):
            self.T.append([0 for j in range(0, neurons_count)])
        
    def learn_rate_t(self):
        return self.learn_rate_init*((self.learn_rate_end/self.learn_rate_init)**(self.t_current/self.t_max))
    
    def lambda_t(self):
        return self.lambda_init*((self.lambda_end/self.lambda_init)**(self.t_current/self.t_max))
    
    def euclidian_norm(self, X):
        value = float()
        for i in range(0, len(X)):
            value += X[i]**2
        return math.sqrt(value)
    
    def get_closer_neurons_count(self, X, idx_i):
        counter = 0
        norm_i = self.euclidian_norm(X-self.W[idx_i])
        for j in range(0, self.neurons_count):
            norm_j = self.euclidian_norm(X-self.W[j])
            if norm_j < norm_i:
                counter += 1
        return counter
    
    def get_closest_and_second_closest_neuron(self, X):
        idx_first = 0
        idx_second = 0
        closest_distance = self.euclidian_norm(X-self.W[0])
        
        for i in range(1, self.neurons_count):
            distance = self.euclidian_norm(X-self.W[i])
            if(distance < closest_distance):
                idx_second = idx_first
                idx_first = i
                closest_distance = distance
        
        return idx_first, idx_second
            

    def work(self, X):
        if(self.t_current >= self.t_max):
            return
        
        X = numpy.array(X)
        #learning of the weights
        self.learn_rate_current = self.learn_rate_t()
        self.lambda_current = self.lambda_t()
        
        for i in range(0, self.neurons_count):
            r_i = self.get_closer_neurons_count(X, i)
            h_i = math.exp(-r_i/self.lambda_current)
            self.W[i] = self.W[i] + self.lambda_current * h_i * (X - self.W[i])
        
        #learning of neighbourhood
        idx_k, idx_j = self.get_closest_and_second_closest_neuron(X)
        
        self.A[idx_k][idx_j] = 1
        self.T[idx_k][idx_j] = 1
        
        for i in range(0, self.neurons_count):
            if(self.T[idx_k][i] > self.tau):
                self.A[idx_k][i] = 0
        
        for i in range(0, self.neurons_count):
            self.A[i][idx_k] = self.A[idx_k][i]
            
        self.t_current += 1
            
    def plot_current_configuration(self):
        plt.plot([self.W[i][0] for i in range(0, self.neurons_count)], \
                 [self.W[i][1] for i in range(0, self.neurons_count)], 'ro')
        
        for i in range(0, self.neurons_count):
            for j in range(0, self.neurons_count):
                if(self.A[i][j] == 1):
                    plt.plot([],[],'ks', [self.W[i][0], self.W[j][0]], [self.W[i][1], self.W[j][1]], 'r-', lw=2)
                    
        plt.axis([0, 513, 0, 513])

        plt.show()