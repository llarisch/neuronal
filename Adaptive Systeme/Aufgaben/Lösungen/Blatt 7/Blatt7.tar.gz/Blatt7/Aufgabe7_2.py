#use python27
import matplotlib.pyplot as plt
import RBF
import numpy

def read_data(dest):
    data = list()
    classes = list()
    fin = open(dest, 'r')
    if not fin:
        fin.close()
        return [], []
    
    lines = list()
    for line in fin:
        lines.append(line[1:].split(' '))
    
    fin.close()

    for i in range(0, len(lines)):
        classes.append(list())
        data.append([float(lines[i][0]), float(lines[i][1])])
        for j in range(2, len(lines[i])):
            if lines[i][j] == '\n':
                continue
            classes[i].append(float(lines[i][j]))
    return data, classes

def plot_data(data, classes, neurons_pos = []):
    colors = ['ro', 'bo', 'go', 'co', 'mo', 'yo','r^', 'b^', 'g^', 'c^', 'rs', 'y^', 'm^', 'bs', 'gs', 'cs', 'ms', 'ys']
    for i in range(0, len(data)):
        plt.plot(data[i][0], data[i][1], colors[classes[i].index(1.0)])
    if neurons_pos != []:
        for i in range(0, len(neurons_pos)):
            plt.plot(neurons_pos[i][0], neurons_pos[i][1], 'ks')
    plt.axis([0, 18, -20, 20])
    plt.xlabel("x")
    plt.ylabel("y")
    plt.show()

if __name__ == '__main__':
    X_training, L_training = read_data("TrainingSet.dt")
    X_validation, L_validation = read_data("ValidationSet.dt")
    X_test, L_test = read_data("TrainingSet.dt")
    
    RBF_Instance = RBF.RBF(40, 16, 3.0, X_training, X_validation, L_validation)
    RBF_Instance.RBF_output(X_training)

    for epoche in range(0, 10):
        print(str(epoche))
        RBF_Instance.training(X_training, L_training)

    
    print("test learning")
    cnt = 0
    RBF_Instance.RBF_output(X_test)
    X = list()
    Y = list()
    for i in range(0, len(X_test)):
        y = RBF_Instance.output(X_test[i], round=True, winnerTakesAll=True)
        if str(y) != str(numpy.array(L_test[i])):
            cnt += 1
        else:
            Y.append(y.tolist())
            X.append(X_test[i])
    print(str(cnt) + "/" + str(len(X_test)) + " not correctly classified")
    plot_data(X, Y, RBF_Instance.get_NeuronRBF_positions().tolist())

