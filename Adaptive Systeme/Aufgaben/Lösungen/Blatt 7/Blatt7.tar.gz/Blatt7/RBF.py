import numpy
import math
import sys
import random

class RBF():
    def __init__(self, cnt_RBF_neurons, cnt_out_neurons, sigmaq, allX, validationX, validationL):
        self.sigmaq = sigmaq
        self.learn_rate = 0.1
        
        self.m = cnt_RBF_neurons
        self.n = cnt_out_neurons
        
        #position of RBFneurons
        self.X0 = list()
        
        for i in range(0, self.m):
            self.X0.append(allX[random.randint(0, len(allX)-1)])
        self.X0 = numpy.array(self.X0)
        
        self.v = list()
        self.Sum = list()
        
        
        #initialize randomly in [-1, 1]
        self.W = numpy.array([[float(random.randint(-100, 100))/1000.0 for i in range(0, self.n)] for w in range(0, self.m+1)])
        
        self.validationX = validationX
        self.validationL = validationL
        
        self.error = list()
        self.counter = 0
        
    def Srbf(self, X):
        return math.exp(-numpy.dot(X, X)/2*self.sigmaq)  
        
    def get_NeuronRBF_positions(self):
        return self.X0

    def output(self, X, round=False, winnerTakesAll=False):
        Sum = 0.0
        v = list()
        for i in range(0, self.m):
            v.append(self.Srbf(X-self.X0[i]))
            Sum += v[i]

        v.append(1.0)
        f = numpy.dot(self.W.T, v)
        f = numpy.dot(1.0/Sum, f)
        
        if winnerTakesAll:
            max_value = -1.0
            max_idx = -1
            for i in range(0, len(f)):
                if f[i] > max_value:
                    max_idx = i
            f = [-1.0 for i in range(0, len(f))]
            f[max_idx] = 1.0
            return numpy.array(f)
            
        if round:
            for i in range(0, len(f)):
                f[i] = -1.0 if f[i] <= 0 else 1.0

        return f
    
    def RBF_output(self, allX):
        for i in range(0, len(allX)):
            Sum = 0.0
            v = list()
            for j in range(0, self.m):
                v.append(self.Srbf(allX[i]-self.X0[j]))
                Sum += v[j]
                
            v.append(1.0)
            Sum += 1.0
            
            self.v.append(v)
            self.Sum.append(Sum)

    def training(self, allX, allL):
        IndexPerm = numpy.random.permutation(len(allX))
        for pattern in range(0, len(allX)):
            idx = IndexPerm[pattern]

            #Sum = 1.0
            f = numpy.dot(self.W.T, self.v[idx])
            f = numpy.dot(1.0/self.Sum[idx], f)

            #delta-rule
            for i in range(0, self.m+1):
                self.W[i] -= self.learn_rate*(f-allL[idx])* self.v[idx][i]/self.Sum[idx]
        
        #validation        
        self.counter += 1
        if self.counter % 20 != 0:
            return 

        self.error = list()
        for i in range(0, len(self.validationX)):
            error = 0.0
            y_validation = self.output(self.validationX[i])
            error_vector = y_validation-self.validationL[i]
            for j in range(0, len(error_vector)):
                error += error_vector[j]**2
            self.error.append(math.sqrt(error))
        
        avg_error = 0.0
        for i in range(0, len(self.error)):
            avg_error += self.error[i]
        avg_error /= len(self.error)
        print("avg error: " + str(avg_error))